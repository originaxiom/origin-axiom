#!/usr/bin/env python3
"""Exact checks of a flag-carrying cusp in the supplied parent.
No repository producers imported. Computational controls are not global PDE proofs.
"""
from pathlib import Path
from collections import Counter
from itertools import combinations, product
from fractions import Fraction
import hashlib,json
import sympy as s

ROOT=Path(__file__).resolve().parent
checks={}
def ck(name, condition):
    value=bool(condition)
    checks[name]=value
    if not value: raise AssertionError(name)
def cl(M): return M.applyfunc(s.simplify)
def zm(M): return cl(M)==s.zeros(*M.shape)
I=s.I
sig=[s.eye(2),s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
N=s.Matrix([[0,1],[0,0]])
# Hermitian matrix basis I,sigma1,sigma2,sigma3, Euclidean positive norm Tr/2.
def L(C):
    return cl(s.Matrix.hstack(*[s.Matrix([s.trace(B*(C*X+X*C.H))/2 for B in sig]) for X in sig]))
def R(M):
    norm=s.sqrt(s.simplify(M.det()*s.conjugate(M.det())))
    return cl(s.Matrix.hstack(*[s.Matrix([s.trace(B*M*X*M.H)/(2*norm) for B in sig]) for X in sig]))

data_bytes=(ROOT/'candidate.json').read_bytes()
ck('candidate_original_git_blob',hashlib.sha1(b'blob '+str(len(data_bytes)).encode()+b'\0'+data_bytes).hexdigest()=='e1e4b140bc27df46d9bc41bfdfebf8464b17fa2d')
data=json.loads(data_bytes)
rep={g:s.Matrix([[s.Rational(a)+I*s.Rational(b) for a,b in row] for row in m]) for g,m in data['holonomy'].items()}
def word(rep,w):
    out=s.eye(next(iter(rep.values())).rows)
    for a in w:out=cl(out*(rep[a] if a.islower() else rep[a.lower()].inv()))
    return out
per=[word(rep,w) for w in data['cusp_words']]
U=[cl(2*M/s.trace(M)) for M in per]
a,b=[M[0,1] for M in U]
ck('actual_peripheral_parabolics',U==[s.eye(2)+a*N,s.eye(2)+b*N])
ck('actual_periods',a==-s.Rational(6,5)+2*I/5 and b==-s.Rational(2,5)+4*I/5)
ck('period_lattice_nondegenerate',s.im(s.conjugate(a)*b)==-s.Rational(4,5))
ck('projective_scalars_cancel_in_physical_four',all(R(P)==R(V) for P,V in zip(per,U)))
# Build source coefficient and cocycle in its own basis to test extension at end.
old_basis=[s.diag(1,0),s.diag(0,1),sig[1],-sig[2]]
def Rold(M):
    cols=[];den=s.sqrt(s.simplify(M.det()*s.conjugate(M.det())))
    for X in old_basis:
        Z=cl(M*X*M.H/den)
        cols.append(s.Matrix([Z[0,0],Z[1,1],(Z[0,1]+Z[1,0])/2,(Z[0,1]-Z[1,0])/(2*I)]))
    return cl(s.Matrix.hstack(*cols))
c=s.Matrix([s.Rational(x)+s.sqrt(2)*s.Rational(y) for x,y in data['cocycle_Qsqrt2_pairs']])
W={}
for k,g in enumerate('abt'):
    V=data['nu'][g]*Rold(rep[g])
    W[g]=V.row_join(c[4*k:4*k+4,:]).col_join(s.Matrix([[0,0,0,0,1]]))
WP=[word(W,w) for w in data['cusp_words']]
ck('literal_rank_five_peripheral_split',all(zm(P[:4,4:5]) for P in WP))
ck('peripheral_parity_is_trivial',all(s.prod(data['nu'][g.lower()] for g in w)==1 for w in data['cusp_words']))
ck('rank_four_log_nilpotence',all((R(V)-s.eye(4))**3==s.zeros(4) and (R(V)-s.eye(4))**2!=s.zeros(4) for V in U))

r,ell,b0,A0=s.symbols('r ell b0 A0',positive=True,real=True)
t=s.exp(-r/ell)
C=[sig[3]/(2*ell),-t*N,-I*t*N] # dr,dX,dY; g=dr2+ell2 exp(-2r/ell)(dX2+dY2)
ck('spin_curvature_rx',zm(s.diff(C[1],r)+C[0]*C[1]-C[1]*C[0]))
ck('spin_curvature_ry',zm(s.diff(C[2],r)+C[0]*C[2]-C[2]*C[0]))
ck('spin_curvature_xy',zm(C[1]*C[2]-C[2]*C[1]))
def moment(Cs):
    As=[cl((x-x.H)/2) for x in Cs]; Ps=[cl((x+x.H)/2) for x in Cs]
    return cl(s.diff(Ps[0],r)-2*Ps[0]/ell+As[0]*Ps[0]-Ps[0]*As[0]+s.exp(2*r/ell)/ell**2*sum((As[j]*Ps[j]-Ps[j]*As[j] for j in (1,2)),s.zeros(Cs[0].rows)))
ck('spin_full_harmonic_moment',zm(moment(C)))
C4=[L(x) for x in C]
ck('Hermitian_rep_respects_adjoint',all(L(x.H)==L(x).T for x in C))
ck('four_curvature_rx',zm(s.diff(C4[1],r)+C4[0]*C4[1]-C4[1]*C4[0]))
ck('four_curvature_ry',zm(s.diff(C4[2],r)+C4[0]*C4[2]-C4[2]*C4[0]))
ck('four_full_harmonic_moment',zm(moment(C4)))
Xi=s.diag(1,1,1,1,-4)
wall=b0*s.exp(2*r/ell)
C5=[s.diag(x,0) for x in C4];C5[0]=C5[0]-wall*Xi
ck('five_tracefree',all(s.trace(x)==0 for x in C5))
ck('Xi_parallel_commutes_all_connection_components',all(zm(Xi*x-x*Xi) for x in C5))
ck('five_curvature_rx',zm(s.diff(C5[1],r)+C5[0]*C5[1]-C5[1]*C5[0]))
ck('five_curvature_ry',zm(s.diff(C5[2],r)+C5[0]*C5[2]-C5[2]*C5[0]))
ck('five_curvature_xy',zm(C5[1]*C5[2]-C5[2]*C5[1]))
ck('five_full_harmonic_moment',zm(moment(C5)))
ck('flag_flux',s.simplify(A0*s.exp(-2*r/ell)*s.trace(Xi*(C5[0]+C5[0].H)/2)+20*A0*b0)==0)
wrong=list(C5);wrong[0]=s.diag(C4[0],0)-b0*s.exp(r/ell)*Xi
ck('wrong_radial_exponent_rejected',not zm(moment(wrong)))
# Norm of background amplitude tangent is exponential, not finite modulus metric.
ck('amplitude_tangent_norm_density',s.simplify(A0*s.exp(-2*r/ell)*s.trace(s.diff(C5[0],b0)**2)-20*A0*s.exp(2*r/ell))==0)
# The retained radial flag kinetic operator on harmonic tangent one-forms.
mu,p=s.symbols('mu p',real=True)
f=s.Function('f')(r);w=mu*s.exp(2*r/ell)
A=lambda F:s.diff(F,r)+w*F
Ad=lambda F:-s.diff(F,r)+w*F
Hm=Ad(A(f));Hp=A(Ad(f))
ck('radial_factorization_minus',s.simplify(Hm-(-s.diff(f,r,2)+(w*w-s.diff(w,r))*f))==0)
ck('radial_factorization_plus',s.simplify(Hp-(-s.diff(f,r,2)+(w*w+s.diff(w,r))*f))==0)
ck('dual_charge_exchanges_partners',s.simplify(Hm.subs(mu,-mu)-Hp)==0)
# canonical flux differs from the ordinary normal derivative.
ck('action_green_identity',s.simplify(A(f)**2+p*p*f*f-(f*(Hm+p*p*f)+s.diff(f*A(f),r)))==0)
ck('missing_Higgs_flux_detected',s.simplify(-A(f)+s.diff(f,r))==-w*f)
# Whittaker substitution x=abs(mu) ell exp(2r/ell).
x,kappa,nu=s.symbols('x kappa nu',positive=True)
Y=s.Function('Y')(x);h=Y/s.sqrt(x)
expr= -4*(x*x*s.diff(h,x,2)+x*s.diff(h,x))+(x*x-4*kappa*x+4*nu*nu)*h
expected=-4*x**s.Rational(3,2)*(s.diff(Y,x,2)+(-s.Rational(1,4)+kappa/x+(s.Rational(1,4)-nu*nu)/x**2)*Y)
ck('Whittaker_equation_transform',s.simplify(expr-expected)==0)
# Closed zero energy wave; formal derivative conditions for opposite wave.
a0=s.symbols('a0',positive=True)
phi= a0*ell/2*(s.exp(2*r/ell)-1)
f0=s.exp(-phi)
ck('normalizable_sign_zero_solution',s.simplify(s.diff(f0,r)+a0*s.exp(2*r/ell)*f0)==0)
ck('opposite_sign_zero_solution_rejected',s.simplify(s.diff(f0,r)-a0*s.exp(2*r/ell)*f0)!=0)
# Partner response identity from the first-order equations, no special functions.
y,z,n=s.symbols('y z n',nonzero=True)
# At r=0 f=1, A f=-n; for g=-Af/n, A_-g=(Hf)/n=-p^2/n.
ck('partner_response_product_algebra',s.simplify(n*(p*p/n)-p*p)==0)
# The zero energy trace axes are maximal null for the Dirac boundary form.
J=s.Matrix([[0,-1],[1,0]])
for key,v in [('plus',s.Matrix([1,0])),('minus',s.Matrix([0,1]))]:
    ck('zero_energy_'+key+'_trace_is_null',(v.T*J*v)[0]==0 and v.rank()==1)
# Branching charge count vs independent E8 roots.
charges=[1,1,1,1,-4]
branch=Counter({0:24+4}) # gauge adjoint + Cartans of structure adjoint
for i,j in product(range(5),repeat=2):
    if i!=j:branch[charges[i]-charges[j]]+=1
for q in charges:branch[q]+=10;branch[-q]+=10
for i,j in combinations(range(5),2):branch[charges[i]+charges[j]]+=5;branch[-charges[i]-charges[j]]+=5
roots=[]
for i,j in combinations(range(8),2):
    for si,sj in product([-1,1],repeat=2):
        rr=[0]*8;rr[i]=si;rr[j]=sj;roots.append(tuple(rr))
for signs in product([-1,1],repeat=8):
    if sum(v<0 for v in signs)%2==0: roots.append(tuple(Fraction(v,2) for v in signs))
vv=[1,1,1,1,-4,0,0,0]
direct=Counter(sum(a*b for a,b in zip(vv,rt)) for rt in roots);direct[0]+=8
ck('E8_root_population',len(roots)==240 and len(set(roots))==240)
ck('full_E8_charge_roster_matches',dict(branch)==dict(direct) and sum(branch.values())==248)
ck('neutral_retained',branch[0]==40)
ck('opposite_charges_retained',all(branch[q]==branch[-q] for q in range(1,6)))
ck('charged_coefficients_not_generations',sum(v for q,v in branch.items() if q)!=0 and sum(v for q,v in branch.items() if q)==208)
# The 4+1 structure end is identity on gauge multiplets, cannot select color/weak.
ng=s.symbols('ng');K=ng*s.eye(5);T=s.zeros(5);T[0,4]=1
ck('derived_structure_end_is_gauge_blind',K*T-T*K==s.zeros(5))
k1,k2=s.symbols('k1 k2');Kbad=s.diag(k1,k1,k1,k2,k2)
ck('unjustified_color_weak_split_detected',(Kbad*T-T*Kbad)[0,4]==k1-k2)
result={'status':'PASS','exact_checks':len(checks),'checks':checks,'peripheral_periods':[str(a),str(b)],'E8_charge_dimensions':{str(q):branch[q] for q in sorted(branch)},'model_scope':'exact nonabelian cusp end and charged radial control; no full nonsplit-core Cauchy match, no global silver spectrum or input selection'}
(ROOT/'EXACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'END_MATRICES.json').write_text(json.dumps({'basis':['I','sigma1','sigma2','sigma3'],'spin_connection':[str(x) for x in C],'four_connection':[[[str(z) for z in row] for row in x.tolist()] for x in C4],'five_connection':[[[str(z) for z in row] for row in x.tolist()] for x in C5],'Xi':str(Xi),'peripheral_normalized':[[[str(z) for z in row] for row in x.tolist()] for x in U]},indent=2)+'\n')
print(json.dumps(result,indent=2))
