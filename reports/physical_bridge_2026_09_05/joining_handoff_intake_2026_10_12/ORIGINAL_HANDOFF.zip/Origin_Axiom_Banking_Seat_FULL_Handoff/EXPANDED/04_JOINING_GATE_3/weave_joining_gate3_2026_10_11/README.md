# Origin Axiom joining gate 3

Read TECHNICAL_REPORT.md for all hypotheses and nonclaims.

The main positive result is an explicit flat/harmonic cusp end preserving the actual m135 peripheral holonomy, carrying the previous flag response, and generating a charged localization wall. An actual gauge-10 peripheral subspace and its conjugate have a fully calculated momentum-dependent end response. Its low-energy norm is finite; opposite signs have different response. The neutral continuum and background-selection question remain.

Reproduce:

    python verify_exact.py
    python verify_numerical.py --dps 50

Dependencies: Python 3, SymPy, mpmath. No network and no repository code imports. The copied candidate input is checked against its original Git blob. All original scientific archives are unchanged.

43 exact predicates and 72 numerical comparisons passed. An 80-digit attempt timed out after the tool limit and is not counted as success. See ATTEMPTS.json. No global silver kernel, independent analytic acceptance, new family count, measured parameter, quantum completion or record-to-E8 necessity is claimed.

Generated files include complete background matrices, detailed results, first execution logs, source pointers and local pre-execution hashes. The hashes are not blind or externally timestamped preregistration.
