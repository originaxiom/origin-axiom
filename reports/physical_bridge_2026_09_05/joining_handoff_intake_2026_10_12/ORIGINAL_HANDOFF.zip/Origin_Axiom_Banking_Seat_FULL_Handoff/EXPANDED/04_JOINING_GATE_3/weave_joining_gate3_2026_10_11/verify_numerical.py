#!/usr/bin/env python3
"""Independent integral/ODE controls for the radial end response.
No imports from verify_exact or repository producers. No interval certificates.
"""
import argparse,json
from pathlib import Path
import mpmath as mp

arg=argparse.ArgumentParser();arg.add_argument('--dps',type=int,default=50)
args=arg.parse_args();mp.mp.dps=args.dps
ROOT=Path(__file__).resolve().parent
checks={};strict=[];limits=[]
tol=mp.mpf(10)**(-args.dps+12)
def check(name,a,b,limit=False,atol=None):
    err=abs(a-b)/(1+abs(a)+abs(b))
    ok=bool(err<(atol or tol))
    checks[name]={'pass':ok,'error':mp.nstr(err,10)}
    (limits if limit else strict).append(err)
    if not ok:raise AssertionError((name,mp.nstr(err,20),mp.nstr(a,20),mp.nstr(b,20)))

def profile_x(x,nu,sigma):
    return mp.whitw(mp.mpf(sigma)/2,nu,x)/mp.sqrt(x)

def integral_data(x,nu,sigma):
    # Tricomi Euler integral with t=y^4 removes quarter-integer endpoint singularities.
    a=nu+(1-mp.mpf(sigma))/2;b=1+2*nu
    if a<=0:raise ValueError('integral requires a>0')
    vals=[]
    for j in range(3):
        g=lambda y:4*y**(4*a-1+4*j)*(1+y**4)**(b-a-1)*mp.exp(-x*y**4)/mp.gamma(a)
        vals.append((-1)**j*mp.quad(g,[0,1,mp.inf]))
    U,Up,Upp=vals
    pref=x**nu*mp.exp(-x/2);k=nu/x-mp.mpf('0.5')
    return pref*U,pref*(k*U+Up),pref*((k*k-nu/x**2)*U+2*k*Up+Upp)

def response(x,nu,sigma,ell):
    f=profile_x(x,nu,sigma)
    fx=mp.diff(lambda t:profile_x(t,nu,sigma),x)
    return -(2*x/ell)*fx/f-sigma*x/ell

# Generic nonzero-frequency points; x,nu,ell are dimensionless diagnostic inputs.
cases=[(mp.mpf('0.4'),mp.mpf('0.25'),mp.mpf('1.3')),
       (mp.mpf('1.1'),mp.mpf('0.75'),mp.mpf('0.8')),
       (mp.mpf('2.3'),mp.mpf('1.5'),mp.mpf('1.7'))]
for k,(x,nu,ell) in enumerate(cases):
    Ns={}
    for sig in (1,-1):
        f,fx,fxx=integral_data(x,nu,sig)
        fw=profile_x(x,nu,sig)
        tag=f'{k}_{sig}'
        check('Euler_integral_value_'+tag,f,fw)
        check('Euler_integral_derivative_'+tag,fx,mp.diff(lambda v:profile_x(v,nu,sig),x))
        check('Euler_integral_second_derivative_'+tag,fxx,mp.diff(lambda v:profile_x(v,nu,sig),x,2))
        residual=-4*(x*x*fxx+x*fx)+(x*x-2*sig*x+4*nu*nu)*f
        check('radial_field_equation_'+tag,residual,0)
        N=-(2*x/ell)*fx/f-sig*x/ell;Ns[sig]=N
        check('canonical_response_'+tag,N,response(x,nu,sig,ell))
        check('response_positive_'+tag,mp.mpf(N>0),1)
        # Intertwiner to the opposite response solution, normalized at this seam.
        y=x*mp.mpf('1.7')
        fy=profile_x(y,nu,sig)/fw
        fyp=mp.diff(lambda t:profile_x(t,nu,sig),y)/fw
        g= -((2*y/ell)*fyp+sig*y/ell*fy)/N
        check('first_order_partner_solution_'+tag,g,profile_x(y,nu,-sig)/profile_x(x,nu,-sig))
    p=2*nu/ell
    check('partner_response_product_'+str(k),Ns[1]*Ns[-1],p*p)
    # Changing cut: the same selected decaying solution at x2 has the directly recalculated response.
    x2=x*mp.mpf('1.9')
    f1=profile_x(x,nu,1);f2=profile_x(x2,nu,1)
    derived=-(2*x2/ell)*mp.diff(lambda t:profile_x(t,nu,1)/f1,x2)/(f2/f1)-x2/ell
    check('moving_cut_preserves_response_'+str(k),derived,response(x2,nu,1,ell))

# Exact zero-frequency formulas, finite kinetic norm and low-frequency response.
zero_results=[]
for k,x in enumerate([mp.mpf('0.2'),mp.mpf('1'),mp.mpf('3')]):
    ell=mp.mpf('1.2');Z=ell/2*mp.exp(x)*mp.e1(x)
    check('zero_sign_plus_whittaker_'+str(k),profile_x(x,0,1),mp.exp(-x/2))
    check('zero_sign_minus_whittaker_'+str(k),profile_x(x,0,-1),mp.exp(x/2)*mp.e1(x))
    norm=ell/2*mp.quad(lambda t:mp.exp(x-t)/t,[x,1+x,mp.inf])
    check('physical_tail_norm_'+str(k),Z,norm)
    check('opposite_static_response_'+str(k),response(x,0,-1,ell),1/Z)
    check('zero_static_response_'+str(k),response(x,0,1,ell),0)
    # Finite-small-p comparison is not assigned the strict numerical precision.
    p=mp.mpf('1e-8');nu=p*ell/2
    check('low_frequency_kinetic_'+str(k),response(x,nu,1,ell)/(p*p),Z,True,mp.mpf('1e-13'))
    check('low_frequency_partner_'+str(k),response(x,nu,-1,ell),1/Z,True,mp.mpf('1e-13'))
    zero_results.append({'x0':str(x),'ell':str(ell),'kinetic_Z':mp.nstr(Z,22),'opposite_N0':mp.nstr(1/Z,22)})

# Independent finite radial interval action identity from integration by parts.
# Bounded interval avoids expensive repeated evaluation at huge exponential argument.
x0=mp.mpf('0.7');x1=mp.mpf('2.1');nu=mp.mpf('0.5');ell=mp.mpf('1.1');sig=1
fbase=profile_x(x0,nu,sig)
def f(t):return profile_x(t,nu,sig)/fbase
def Ar(t):return (2*t/ell)*mp.diff(f,t)+sig*t/ell*f(t)
integral=mp.quad(lambda t:ell/(2*t)*(Ar(t)**2+(2*nu/ell)**2*f(t)**2),[x0,x1])
boundary=f(x1)*Ar(x1)-f(x0)*Ar(x0)
check('finite_interval_actual_quadratic_action',integral,boundary)
# Limiting response at fixed p as end amplitude decreases returns the previous cusp threshold.
x=mp.mpf('1e-12');ell=mp.mpf(1);nu=mp.mpf('0.75');p=2*nu
for sig in (1,-1):
    check('zero_wall_limit_'+str(sig),response(x,nu,sig,ell),p,True,mp.mpf('1e-9'))

out={'status':'PASS','dps':args.dps,'checks':checks,'total_checks':len(checks),'strict_count':len(strict),'finite_limit_count':len(limits),'max_strict_residual':mp.nstr(max(strict),20),'max_finite_limit_residual':mp.nstr(max(limits),20),'zero_response_examples':zero_results,'scope':'rank-one charged radial control, not full parabolic E8 matrix response or global core spectrum'}
(ROOT/f'NUMERICAL_{args.dps}.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
