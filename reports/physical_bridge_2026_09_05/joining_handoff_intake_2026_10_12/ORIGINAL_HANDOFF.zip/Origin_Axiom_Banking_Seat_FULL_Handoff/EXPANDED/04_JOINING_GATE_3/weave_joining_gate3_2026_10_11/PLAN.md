# Joining gate 3: physical response of the flux-carrying end

11 October 2026. Written after analytic exploration, before the formal verifiers. Not blind preregistration and not remotely timestamped.

## Input and model
Reuse Gate 2's complete cusp metric and its permitted radial flag-current solution. Reuse the supplied parent's flatness/moment-map residual potential and Hodge/Weyl kinetic structure. Do not add particles, boundary projectors or potentials. The original compact selective boundary is NOT automatically transferred to this complete end.

Try to retain the actual m135 peripheral holonomies by constructing a nonabelian rank-four harmonic cusp connection. Add only the commuting flag response already present in Gate 2. Check its full curvature and moment map. The end may still not match the complete nonsplit core's normal data.

## Tests
1. Reconstruct the actual two projective peripheral holonomies from the unchanged candidate input, not a desired Jordan form. Check determinant-normalized Hermitian transport and the literally split rank-five peripheral extension.
2. Construct the rank-four real representation of a flat harmonic SL2 cusp connection and its rank-five flag deformation. Test every curvature and moment component, true adjoints, flux, and a deliberately wrong radial exponent.
3. Derive the physical tangential one-form action, radial factorization, canonical boundary flux and stable zero-energy end traces. Keep opposite charges and first-order partners. Do not call an end solution a global particle without core matching.
4. Solve the rank-one response in Whittaker functions. Check against an independent integral representation, ODE, positive quadratic action identity, partner-response identity and low-frequency norm. Keep the Higgs term in canonical flux.
5. Compare the E8 charge list by inherited A4+A4 branching with direct standard E8 root enumeration. Preserve all neutral generators and neutral cusp continuum.
6. Test amplitude variations in the actual kinetic norm, not the harmonic-map functional. No parameter or topological integer is to be declared selected from an admitted family alone.

## Expected scope
May derive an actual localization wall and its response conditional on an existing permitted nonzero end current. Does not derive E8, spacetime, a global nonsplit solution, the end current's value, SM selectivity, a family number, quantum stability, metric backreaction or gravity. Known Witten-deformed Dirac/Whittaker machinery is not claimed as novel. A full global kernel or an interacting quantum determinant is not computed.

Existing strong-source and form-parent work is credited. Targeted repository searches do not establish all-branch absence. The new physical head 0cc9eb41 has advanced the charged-cubic work; that calculation is not duplicated here.
