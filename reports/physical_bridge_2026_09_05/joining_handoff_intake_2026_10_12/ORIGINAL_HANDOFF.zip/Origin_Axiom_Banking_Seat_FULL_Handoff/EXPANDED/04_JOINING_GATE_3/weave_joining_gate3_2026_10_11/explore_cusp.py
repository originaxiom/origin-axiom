import sympy as s,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
with zipfile.ZipFile('/mnt/data/Weave_Record_to_Physics_Joining_Gate_1.zip') as z:
 data=z.read('weave_record_operator_gate_2026_10_11/candidate.json')
(root/'candidate.json').write_bytes(data)
d=json.loads(data)
M={g:s.Matrix([[s.Rational(a)+s.I*s.Rational(b) for a,b in row] for row in m]) for g,m in d['holonomy'].items()}
def ev(w):
 t=s.eye(2)
 for l in w:t=(t*(M[l] if l.islower() else M[l.lower()].inv())).applyfunc(s.simplify)
 return t
for w in d['cusp_words']:
 P=ev(w);print(w,P,'trace',s.trace(P),'det',s.factor(P.det()))
 U=(2*P/s.trace(P)).applyfunc(s.simplify)
 print('unipotent normalized',U)
