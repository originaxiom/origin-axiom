from pathlib import Path
import json, hashlib, zipfile
base=Path('/mnt/data/origin_axiom_cross_branch_review_2026_10_11')
repo='originaxiom/origin-axiom'
branches=[
 ('main','6c148ddd495d133213140995976ff08849793d5d','Canonical GENESIS v1.41 and banked weave results; GENESIS, campaign status and B1634 findings read.'),
 ('audit/fork-2026-09-20','b7a51ac7094ea5b1e800598238a51890d9345dfc','Latest genesis status, cross-branch reproduction, puncture result and successor reasoning read.'),
 ('audit/physical-bridge-2026-09-05','142d3adf3dd89dbfcc05f729170489f4da8e916d','Completed results read at 1ba34144f3deadc698a53f8d4acb4b472e42c300; final head adds a selective-boundary PRE-EXECUTION seal, not a new verified result.'),
 ('claude/standard-model-derivation-0qt6ao','6877cc87d31941a85f139e2f25e5e13694e22ce6','Head commit, W53 findings/relay diff and genesis successor interpretation read; fit not rerun.'),
 ('chat1/web-seat','d40c1ab6ec7201c1a0763b6a70a1b265c86aa3ee','Head metadata and detailed verification addendum/diff read; underlying complete historical census not replayed.'),
 ('claude/project-thread-hctlox','8b6df98ffe9a4ed5d8320140b6ab3e89da2fe511','Latest LP01 common-cover findings update, recorded controls and output diff read.'),
 ('claude/paper-review-verification-kaz3f5','5d58b935b6001ce09dfed8e0bdc6fd8da71f77fd','October 1 sweep and corrected review findings in head diff read; historical claims not automatically current.'),
 ('claude/outside-bench','13d2c5b63ba7a3db9ea880016a43d3c688cee954','README and latest memo-236 correction read; historical text separated from October canonical state.'),
 ('sep16-branch','3205984b48d1b98a80042cdc70916878973980f5','Latest schema-repair and cross-branch/methodology changes read.'),
 ('claude/kind-hypatia-uk0vv9','6a537f899c9c1882930475144a30ae76aa2966d8','Latest B1035 pinned-receipt reproducibility repair and related diff read.'),
 ('chatgpt/weave-physics-archive-2026-10-11','d7e4afeb7d0e13eb786f50893f02fe18b965520c','Head inventoried; latest physical-branch archive intake read. Remote recovery ZIP not reported present; staging is not complete remote preservation.')]
P='1ba34144f3deadc698a53f8d4acb4b472e42c300'; G=branches[1][1]; M=branches[0][1]
sources=[
 ('S01',M,'GENESIS.md','Canonical assumptions and conditional meanings; relevant initial sections read.'),
 ('S02',M,'frontier/B1634_w50_on_main/FINDINGS.md','Genuine metaplectic multiplier and corrected instrument; full findings returned.'),
 ('S03',M,'docs/CAMPAIGN_STATUS.md','Newest main status and historical qualifications; excerpt only.'),
 ('S04',G,'reports/genesis_root_review_2026_10_11/STATUS_AND_PLAN.md','Foundational consolidation, carrier alternatives, cusp selection and active operator task.'),
 ('S05',G,'reports/genesis_root_review_2026_10_11/CROSS_BRANCH_REPRODUCTION.md','Read in latest commit diff; reproduction scope and retained failures.'),
 ('S06',G,'reports/genesis_root_review_2026_10_11/puncture_symmetry/FINDINGS.md','One suitable sign suffices under retained move/graded assumptions; no physical end selection.'),
 ('S07',P,'reports/physical_bridge_2026_09_05/README.md','First 220 lines; newest-to-oldest physical checkpoints.'),
 ('S08',P,'reports/physical_bridge_2026_09_05/silver_physical_multiplets_2026_10_11/FINDINGS.md','Conditional all-degree spectrum and 1,890 rank strata / 350 local-anomaly-free strata.'),
 ('S09',P,'reports/physical_bridge_2026_09_05/silver_adjoint_phase_2026_10_11/FINDINGS.md','Same-action SM gauge phase, interaction formula, retained adjoint/neutral modes and choices.'),
 ('S10',P,'reports/physical_bridge_2026_09_05/silver_charged_pair_lift_2026_10_11/FINDINGS.md','Generic small-phase lifting; conditional one/two chiral matter sets; special-plane exceptions.'),
 ('S11',P,'reports/physical_bridge_2026_09_05/silver_framed_coupled_domains_2026_10_11/FINDINGS.md','Same-boundary positive-mass multiplets and free Gauss evolution; Run 13 credited.'),
 ('S12',P,'reports/physical_bridge_2026_09_05/silver_higgs_scope_2026_10_11/FINDINGS.md','Higgs doublet/colour pairing and persistent adjoints; selective boundary changes hypotheses.'),
 ('S13',P,'reports/physical_bridge_2026_09_05/weave_archive_intake_2026_10_11/FINDINGS.md','All-run file custody, partial scientific reading and remote incomplete-archive state.'),
 ('S14',P,'reports/physical_bridge_2026_09_05/seat_sync_after_higgs_2026_10_11/FINDINGS.md','Latest commit diff read; distinguishes input-selection from physical consistency.'),
 ('S15',branches[2][1],'reports/physical_bridge_2026_09_05/silver_selective_boundary_2026_10_11/DESIGN.md','Read in final head commit diff: pre-execution hypothesis, NOT reported completed result.')]
snap={'repository':repo,'review_date':'2026-10-11','recorded_at_utc':'2026-10-11T11:51:39Z','live_branch_count':11,'branch_inventory_ref':'GitHub branch endpoint, per_page=100','branches':[{'name':n,'sha':s,'reading_depth':d,'url':f'https://github.com/{repo}/tree/{s}'} for n,s,d in branches], 'limitations':['No local git clone: direct git request failed DNS resolution.','Connected GitHub reads and branch/head diffs, not an exhaustive download or reading of every file.','No repository scientific producer or test suite was rerun.','No branch, main file, workflow or persistent library was changed.','Only advertised live branches were inventoried; deleted, tagged-only and unpublished local work is outside the inventory.','Research report grades are preserved; internal or same-author checks are not external analytic acceptance.'], 'sources':[{'id':i,'sha':s,'path':p,'reading_note':note,'url':f'https://github.com/{repo}/blob/{s}/{p}'} for i,s,p,note in sources]}
(base/'BRANCH_AND_SOURCE_SNAPSHOT.json').write_text(json.dumps(snap,indent=2,ensure_ascii=False)+'\n')
report=r'''# Origin Axiom — cross-branch progress assessment

**Snapshot: 11 October 2026.** This is a source-based research assessment, not a new mathematical verification run. The companion JSON records all 11 live branch heads, reading depth and source pins. No repository files were changed.

## Overall judgment

The programme has two substantial achievements that must not be confused with their unfinished connection. First, it has a precise mathematical construction relating record moves, quaternion/parity cohomology and a known metaplectic theta multiplier. Second, it now has a considerably more coherent conditional gauge-theory model: a supplied compact twisted E8 parent, an admitted background, boundary conditions, physical operators, a real gauge quotient, massless and massive multiplet organization, an admitted Standard-Model gauge phase, and a scoped mechanism lifting unwanted charged conjugate pairs.

These are real mathematical and conditional physical advances. They do not yet amount to one derived model of our universe. The main unresolved interface is from the foundational record construction to the physical action, field representation, kinetic metric, grading and boundary/end law. The closest concrete obstacles within the leading physical model are three-family capacity, a viable Higgs sector and the remaining adjoint/neutral states. Normalized empirical predictions and a complete gravitational/quantum theory remain unestablished.

The most useful description is **a strong mathematical core plus a developing conditional particle-theory construction, with foundational selection and observed-physics tests still unfinished**. This is an assessment, not a percentage-complete score.

## What was retrieved

All 11 advertised heads were inventoried and their latest metadata, source changes or current reports examined at the depth stated in the JSON. The active physical branch changed during the review: completed findings were read at `1ba34144...`; the later `142d3adf...` commit is a pre-execution seal for a changed selective boundary. Its intended outcome is not promoted to a result.

A direct local git request failed DNS resolution. Retrieval therefore used the connected GitHub reader. This is not a full clone, all-history audit, exhaustive reading of every branch file, or test-suite replay. Older audit branches are historical evidence, not automatically newer authority than canonical GENESIS v1.41 and their successor reports.

## Strongest result 1: exact structure rather than an attractive dimension

Main B1634 identifies the weave's lifted triplet with the multiplier of

    eta(tau)^21 (theta_2(tau)^2, theta_3(tau)^2, theta_4(tau)^2).

The reported T-exponents are 1/8, 3/8 and 7/8; the representation is genuinely metaplectic. Its significance is the explicit action/intertwiner, not merely that three functions exist. The earlier projective-only diagnosis was traced to a helper's lift-sign convention; a separate theta-law failure was traced to the principal branch of a fractional nome power. The record retains those failures and repairs.

The limitation belongs beside the positive: the same modular count at the stated matter weight is zero without additional end data. Recovering a conditional three still uses the physical link Lambda and a cusp unit. The group-theoretic chirality of T is not by itself a gauge-chiral particle spectrum. [S01–S03]

The golden-spectrum work should be valued as mathematics, not as an observed-mass success. The source manuscript itself excludes its lowest zero-diagonal texture for charged fermions. Our earlier whole-axis proof is a candidate in the separate archive; the receiving archive assessment does not certify that proof or all early runs. [S13]

## Strongest result 2: several physics obligations now refer to one model

The physical branch no longer has only cohomology counts awaiting an unexplained particle label. Its completed reports connect the action, positive kinetic metric, admitted compact boundary, Weyl/Hodge operator, real gauge slice, scalar Hessian and vector constraint. They retain actual conjugates, H0/H3 gauge endpoints and the distinction between smooth compatibility equations and closed operator domains.

Its framed-domain follow-through extends the positive-mass organization to the SM phase without silently changing the old boundary gauge algebra. Positive degree-zero modes supply massive vector multiplets with a physical imaginary exact scalar; co-closed one-forms supply massive chiral multiplets; the free reduced Gauss Hamiltonian is positive. Our Run 13 is explicitly credited for the original-reference organization rather than counted as a separate discovery. [S07, S08, S11]

Evidence grade: authored conditional global analysis, supported by exact local and finite checks. This review did not rerun the producers or independently establish the global elliptic/Hilbert-complex arguments. It is not a nonlinear Hamiltonian, full interacting Kaluza–Klein truncation or complete quantum theory.

## Strongest result 3: an admitted SM gauge phase plus scoped chiral-pair lifting

The branch constructs

    Phi_v = Phi_star + v H omega,   H = diag(2,2,2,-3,-3),

on its equal gauge-line boundary choice. This is a flat, moment-zero stationary branch in the same supplied action. Its actual vector kernel has the connected group [SU(3) x SU(2) x U(1)]/Z6. The construction checks an operator kernel on the boundary-framed model, not only an abstract subgroup embedding. [S09]

For sufficiently small nonzero phase and generic fixed charged planes, the next packet shows that unwanted conjugate pairs can lift while protected chiral content survives. Conditional examples have one or two complete chiral 10 + bar5 matter sets. Exceptional planes retaining pairs remain in the report. A zero first-order mass map is explicitly shown not to preclude lifting at higher order. [S10]

This is significant physical model-building progress. It does not select the 3+2 Cartan direction, phase, equal gauge line, metric, parent or boundary. A generic Cartan direction has a different unbroken group. The common net index of this specific family is bounded by two; a three-family result elsewhere cannot simply be attached to this model without a map. [S08–S10]

## Strongest result 4: foundational work is removing or locating real assumptions

The genesis fork now distinguishes coherent presentation conventions from physical choices. Its word-lift and bundle-transport work gives explicit maps rather than charging for equivalent insertion-order conventions twice. Its carrier counterexamples show that preserving positive descriptions does not force full signed free-group fidelity; the retained cohomology requires more information than a metabelian quotient but not necessarily every signed free-group distinction.

The new puncture result weakens one sufficient assumption: joint move invariance plus one suitable order-two flavour sign can exclude the intermediate graded subspaces. Full continuous flavour invariance is unnecessary for that particular step. It retains the grading/index dictionary, supplied embedding and boundary interpretation; it does not select a physical cusp unit. [S04–S06]

The cross-branch reproduction is useful: the physical lane reports rerunning five unchanged genesis producers; the fork replayed its separate-method reference with identical output. This strengthens those scoped calculations, not every later packet, physical premise or full-suite certificate. [S05]

## Weakest joint 1: the original weave and the physical parent are not yet one derived construction

The two successful chains currently have different starting data:

    record grammar -> parity/cohomology -> metaplectic T

and

    supplied E8 parent + metric + boundary -> physical modes -> admitted SM phase.

The missing map must specify the actual coefficient bundle, field, real structure, kinetic operator, grading, domain and end data. A rank-six SU6/parity construction must not be identified with the rank-five SU5 silver coefficient by a shared word such as 'three' or 'chiral'. A matter-twisting line is not automatically a determinant line over a family of operators. [S04, S14]

GENESIS also retains postulated grammar and a surface/carrier choice. The philosophical principle has not by itself derived the entire physical action. Calling all clauses of Lambda 'one assumption' does not remove the clauses. The latest genesis review explicitly recognizes this. [S01, S04]

## Weakest joint 2: boundary/end choice still controls the answer

The completed massless census has 1,890 rank-labelled multiplicity patterns and 350 with vanishing local SU5 cubic anomaly. These are not 350 selected vacua, and they do not enumerate the continuously many boundary planes as finitely many physical states. [S08]

The mathematical classification clarifies dependence on a boundary choice; it does not explain why the physical boundary is that choice. Likewise, the genesis Hodge-line construction can realize supplied flux, but its specified energy prefers zero if zero is admitted. Producing a solution in a nonzero sector does not show that earlier data or the action require that sector. [S04–S06]

A useful next derivation must remove a named independent input without consulting the desired family count. A changed boundary can be worthwhile conditional physics, but it needs a separate selection argument.

## Weakest joint 3: Higgs splitting, excess states and three families are concrete obstacles

The completed phase retains twelve adjoint chiral profiles and six to twelve neutral chiral profiles. The twelve adjoint profiles have nonlinear quartic interactions; they are not all jointly unobstructed moduli. However, a quartic at the chosen origin is not a quadratic mass. [S09, S12]

Under the tested common SU5 boundary planes, the weak-doublet and coloured parts of the vectorlike 5/bar5 pair are generically retained or lifted together. A selective choice can give a desired algebraic distinction, but it fails the OLD full-SU5 boundary gauge law. Removing coloured partners while retaining a Higgs pair is therefore not yet accomplished in that unchanged completed model. [S12]

The latest head, `142d3adf...`, explicitly proposes a NEW component-selective boundary with the maximal stabilizer S(U3 x U2). It is a pre-execution design at this snapshot. Its hypothesized reduced adjoint content or surviving Higgs pair is not yet a verified result. Even success would leave its supplied 3+2 partition and boundary selection to explain. [S15]

The current family's exact common-index range -2..2 is a constraint on that family, not a universal no-go for the architecture. It does mean that repeating the unchanged-family scan cannot produce three.

## Weakest joint 4: the quantitative phenomenology is not yet positive

The SM branch's W53 reports a very poor best-found fit for the common-weight-three 11-parameter flavour ansatz: chi-squared about 1,887 under its stated ten-percent logarithmic allowance, and about 484 under twenty percent. A masses-only test also fails badly. Its common modulus ties the sector hierarchies too tightly in the investigated regime.

Those are reported finite-optimization outcomes. They are evidence against the tested ansatz, not an independently certified global minimum or a theorem excluding every modular-flavour construction. The newer genesis review retains that scope correction. No source reviewed here establishes a successful parameter-reducing fit, much less parameter-free Standard-Model values. [SM head `6877cc87...`; S04]

The physical branch supplies a canonical normalized-overlap formula, but does not evaluate the actual global harmonic profiles, overlap integrals or measured masses on the silver background. An expression for Y_ABC is not a computed empirical prediction. [S09, S10]

## Weakest joint 5: quantum and gravitational completion

Local representation anomaly cancellation is necessary but is not a complete boundary/inflow, global-anomaly or ultraviolet-consistency certificate. Positive quadratic evolution does not select a quantum vacuum or establish a nonperturbative interacting completion. The physical reports state these limitations rather than resolving them. [S08–S12]

The parent framework and boundary tools have established literature antecedents. This supports their use as frameworks; it does not transfer every conclusion of M-theory or G2 compactification to the repository's particular supplied model. The programme still owes the relevant gravitational dynamics and spacetime interpretation in the same construction. Older local G2/three-dimensional CS geometry is not a substitute for that missing complete model.

## Weakest joint 6: evidence integration and verification debt

The record is unusually explicit about failures, opposite controls and assumptions. That is a strength. It also has concrete failure modes: stale status pages, duplicated work because searches omitted papers or other branches, same-size/same-name physical identifications without maps, and gate runs mistaken for complete test suites. Historical audit branches document these problems and corrections.

The latest physical reports still disclose four inherited governance-failure categories and no full-suite/main-bank/external analytic acceptance. The genesis puncture report retains its earlier failed full suite and five governance categories. Those facts do not refute every new result; they prevent interpreting a focused passing test count as whole-program certification. [S06, S09–S12]

The 13-run archive has verified local/source custody in the physical intake, but the dedicated remote archive branch still lacks the full recovery ZIP at the reviewed pin. Preservation, reproduction and scientific correctness are separate claims. [S13]

## Recommended programme order (assessment, not a source theorem)

1. Keep the mathematical weave chain and the conditional physical-model chain distinct until an explicit field/operator/domain map joins them. The highest-leverage foundational result would force a presently supplied physical or end-law input.
2. Complete the new boundary/Higgs admission test with the entire roster, then state exactly which old assumptions changed. Treat three-family capacity as a separate same-model requirement; do not import a count from another carrier by analogy.
3. Choose an admitted background and compute an actual normalized observable relation with an explicit input budget. Parameter dependence is itself a result; a relation surviving unfitted freedom is more informative than another matching dimension.
4. Obtain independent review of the compact boundary Hilbert complex, physical Weyl correspondence and phase-family kernel comparison. Reconcile the relevant regression failures on pinned environments. More finite checks are not a replacement for that analytic review.

The immediate aim is one coherent, falsifiable, anomaly-accounted candidate with controlled inputs. That is not a retreat from the TOE goal: it is the point at which the different successful mathematical pieces can be tested as one physical proposal.

## Bottom line

**Strongest mathematics:** the actual lifted representation and explicit maps, not the repeated number three.

**Strongest physics:** a conditional same-action SM gauge phase with physical operator/domain control and scoped pair lifting.

**Weakest foundational joint:** why this action, matter dictionary and boundary/end data follow from the record rules.

**Weakest near-term physical joint:** three families together with a viable Higgs sector and removal of unwanted light fields.

**Weakest empirical/TOE joint:** normalized successful predictions, full quantum consistency and gravitational dynamics.

There is meaningful progress. There is not yet a verified derived theory of our universe, and a percentage-complete score would hide rather than describe the remaining dependencies.
'''
# Include a precise branch table and references in the downloadable report.
report+='\n## Complete live-branch snapshot and review depth\n\n| Branch | Head | Reading scope |\n|---|---|---|\n'
for name,sha,depth in branches: report+=f'| `{name}` | `{sha[:12]}` | {depth} |\n'
report+='\n## Pinned source map\n\n'
for sid,sha,path,note in sources:
    report+=f'- **{sid}** — `{path}` at `{sha}`. {note}\n  https://github.com/{repo}/blob/{sha}/{path}\n'
report+='\n## External framework checks (not verification of the repository application)\n\n- Christoph Lüdeling, arXiv:1102.0285, Seven-Dimensional Super-Yang-Mills Theory in N=1 Superfields.\n- Braun et al., arXiv:1812.06072, Higgs Bundles for M-theory on G2-Manifolds.\n- Bär and Ballmann, arXiv:1307.3021, Guide to Boundary Value Problems for Dirac-Type Operators.\n'
(base/'ASSESSMENT.md').write_text(report)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in base.iterdir() if p.name!='MANIFEST.json'}
(base/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
zip_path=Path('/mnt/data/Origin_Axiom_Cross_Branch_Review_2026-10-11.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(base.iterdir()): z.write(p,p.name)
print('Report words:',len(report.split()))
print('Branches:',len(branches),'Sources:',len(sources))
print('Zip bytes:',zip_path.stat().st_size)
