# Joining gate 2 — derive the seam response, then test the completion

**Date:** 11 October 2026. **Status:** authored conditional analysis with exact algebraic and radial controls. No independent specialist acceptance, full E8 PDE solution, quantum completion, new particle census, or upstream derivation of the parent is claimed.

## Executive result

An artificial cut is not entitled to an independently chosen boundary response. Once the exterior differential operator, metric and state/end prescription are fixed, eliminating that exterior determines the response. This familiar gluing principle gives a concrete route toward replacing a boundary input by an equation. It does not by itself select the exterior theory or its asymptotics.

I tested it on a complete hyperbolic cusp, in commuting scalar/form channels present in the supplied gauge/Hodge parent. The response is derived, not chosen: for harmonic tangential q-forms it is

    N_q(p) = sqrt(p^2 + ((1-q)/ell)^2) - (1-q)/ell,    p>0.

In the physical tangential one-form channel, N_1(p)=p. Its zero-frequency limit is not an ordinary normalizable zero mode. Explicit escaping Weyl sequences put the entire interval [0,infinity) in the essential spectrum of that channel. Consequently the restored complete cusp is not interchangeable with the source's gapped-above-zero compact-core realization.

A separate nonlinear test uses the source's negative flag-current identity. A smooth harmonic continuation of the nonsplit rank-five coefficient through a shrinking cusp has a quantitative divergent lower bound on integral |Psi|^2. This is a harmonic-metric norm criterion, NOT a divergence of the supplied residual potential. A sharp radial control has zero flatness/moment residuals while violating this norm criterion. The distinction is essential.

Finally, eliminating an exterior which preserves the full gauge symmetry cannot generate a color/weak-selective response. Such selectivity requires a symmetry-breaking exterior/background/state or a real interface mechanism, rather than an arbitrary redraw of a cut.

**Input outcome:** no extra response function is needed in the explicitly solved exterior channels. However, the programme's actual selective charged domain, nonzero extension, positive metric and modular cusp unit have not been derived. This is a tested completion mechanism and a discriminating obstruction to a particular minimal completion, not the requested full joining theorem.

## 1. Source custody and what was not recomputed

The beginning-of-run branch inventory pinned:

- main: 6c148ddd495d133213140995976ff08849793d5d;
- foundational fork: b7a51ac7094ea5b1e800598238a51890d9345dfc;
- physical branch: cba986752e8c1b5c49f70c91909d4aa869886ded.

The physical head seals the next charged-cubic calculation. It is not evidence that its proposed charged-cubic results have already executed. This run neither duplicates that calculation nor adopts any unexecuted outcome.

The preceding Joining Gate 1 report was read in full. Two additional full source proofs were read on the fork:

1. reports/free_boundary_completion_2026_10_04/PROOF.md;
2. reports/silver_normal_response_2026_10_04/PROOF.md.

They already prove and explicitly distinguish:

- a compact Dirichlet harmonic metric conditional on a chosen boundary metric;
- the real Jacobi operator and its Dirichlet coercivity;
- Dirichlet-to-Neumann kinetic norms of boundary variations;
- infinite-dimensional null directions if the bare physical boundary is released without a replacement;
- the negative nonsplit flag response and its small-extension expansion;
- zero bare residual potential for both split and nonsplit admitted flat/harmonic members;
- the fact that harmonic-map energy is NOT that bare potential.

Those are prior results. The new work tests *restoration and elimination of a complete exterior*, actual cut composition, its spectral threshold, and the quantitative end-integrability consequence of the flag identity. This is not a novelty claim for Dirichlet-to-Neumann operators, spectral gluing or known hyperbolic cusp spectra. Targeted default-branch searches cannot certify all-branch absence; the positive predecessor hits were followed rather than ignored.

No source repository code was imported or executed. No source file or remote branch was changed. The complete-cusp comparison changes the end/domain relative to the compact selective model; none of its particle counts is transferred.

## 2. The proposed implication: an artificial cut is eliminated, not assigned a new law

Let a complete model be decomposed into a core X and exterior Y along a surface Sigma. This decomposition alone introduces no physical membrane. At the quadratic Euclidean level, fix the operator on Y and an end prescription for which its positive-frequency Dirichlet problem is unique. Let f be the boundary value and u_f its exterior solution. Define the Dirichlet-to-Neumann map by

    N_Y(p) f = exterior outward normal canonical flux of u_f at Sigma.

For a normalized scalar channel, integration by parts gives

    S_Y,on(f) = (1/2) <f, N_Y(p) f>_Sigma.

Core stationarity therefore becomes

    Pi_X + N_Y(p) f = 0,

where Pi_X is the outward canonical flux from the core. The opposite normal orientations are included in this sum. If a genuine boundary action S_defect is introduced, its variation is added to the equation; that is extra physical structure, not a coordinate convention.

### Exact finite-dimensional proof and quantum normalization

For positive Gaussian data

    H = [[A,B],[B^T,C]],    C>0,

eliminating the exterior variables y gives

    K = A - B C^-1 B^T,
    y_classical = -C^-1 B^T x.

The exact identities are

    (x,y)^T H (x,y)
      = x^T K x + (y+C^-1 B^T x)^T C (y+C^-1 B^T x),
    det H = det C det K,
    (H^-1)_boundary = K^-1.

Successive elimination gives the same K as direct elimination. The Gaussian integral also contains (det C)^(-1/2). Dropping that factor is not exact quantum gluing. In the continuum it requires a specified regularization and counterterms; this packet does not compute the interacting E8 determinant or its anomaly.

This is the standard exterior-response construction, concretely checked here. It is not a theorem deriving a physical parent from the record grammar. Nor may an energy-dependent transparent response automatically be treated as a fixed selfadjoint boundary condition for an isolated core at all energies: selfadjointness belongs to the full core-plus-exterior problem, and the eliminated exterior can carry a continuum.

## 3. A tractable exterior inside the actual Hodge-type kinetic structure

Take the explicit comparison metric

    Y = [0,infinity)_r x T^2,
    ds^2 = dr^2 + exp(-2r/ell) h_T,
    ell>0.

Here ell and h_T are supplied geometry, not derived scales. Choose a compact coefficient generator commuting with the background connection and Higgs field. Such parallel unbroken gauge channels are retained in the source's field roster. On this channel the covariant exterior differential reduces to the ordinary one. This does not diagonalize the full nonunitary charged silver connection.

Let omega_q be a harmonic tangential q-form on the flat two-torus, normalized at r=0. For a profile f(r) omega_q the radial norm has weight

    w_q(r) = exp(-2 a_q r),      a_q = (1-q)/ell.

The factor is derived from the inverse metric on q covector indices times the volume element. It must not be replaced with the scalar weight for all form degrees.

For Euclidean external momentum magnitude p, the normalized quadratic channel is

    S_q,p = (1/2) integral_0^infinity
              w_q(r) [ |f'(r)|^2 + p^2 |f(r)|^2 ] dr.

Its radial operator is

    P_q = -d^2/dr^2 + 2 a_q d/dr.

The unitary change u=exp(-a_q r) f gives

    P_q -> -d^2/dr^2 + a_q^2.

Equivalently the paired form block has Dirac expression

    Q_q = [[0, -d/dr+a_q],[d/dr+a_q,0]],
    Q_q^2 = (-d^2/dr^2+a_q^2) I.

The displayed q-form calculation assumes zero tangential Laplacian eigenvalue. Nonzero-frequency scalar channels were additionally checked with Bessel functions; those scalar checks are not asserted as formulas for every coupled nonzero-frequency form block.

### The derived response

For p>0, the unique L2/finite-action solution with f(0)=f0 is

    f(r)=f0 exp[(a_q-sqrt(a_q^2+p^2))r].

The other solution grows in the weighted norm. Since the exterior normal at r=0 is -d/dr,

    N_q(p) = sqrt(a_q^2+p^2)-a_q,
    S_q,p,on = (1/2) N_q(p) |f0|^2.

In particular:

- q=0: N_0(p)=sqrt(ell^-2+p^2)-ell^-1;
- q=1: N_1(p)=p;
- q=2: N_2(p)=sqrt(ell^-2+p^2)+ell^-1.

The q=1 field is not just an auxiliary metric coordinate. In the commuting one-form sector, its internal potential is ||d(f omega_1)||^2, its moment/divergence is zero, and its external kinetic norm is integral |f|^2 dr. It is therefore an actual quadratic scalar/form channel of the supplied parent under this complete-cusp comparison. A nontrivial torus harmonic one-form is not an exact periodic gauge gradient.

For q=0 and nonzero torus frequency k>0, the scalar solution is

    f(r) = exp(r/ell) K_nu(k ell exp(r/ell))/K_nu(k ell),
    nu = sqrt(1+ell^2 p^2).

The response is -f'(0), with the derivative evaluated independently using both direct differentiation and neighboring Bessel orders. This is a separate nontrivial control of the warped geometry.

## 4. Cut composition and the zero-frequency trap

For the q=1 channel, the action on a finite interval of length L has endpoint matrix

    K_L(p) = p [[coth(pL),-csch(pL)],[-csch(pL),coth(pL)]].

Join intervals of lengths L1 and L2, then eliminate the middle endpoint. The result is exactly K_(L1+L2). Terminate a finite interval with the actual half-line response p; eliminating the far endpoint returns p at the near endpoint, independently of L.

This is the operational sense in which moving an artificial cut does not select a new response. If the far endpoint instead has an independently supplied Robin coefficient beta, the effective response changes. A different beta is different physics, not the same whole geometry redrawn.

### A limit of a response is not necessarily an admitted zero mode

For q=1, at p=0 the radial equation has f=A+Br. No nonzero solution belongs to L2([0,infinity),dr). Yet

    lim_(p down to 0) N_1(p)=0.

For f_p=exp(-pr),

    ||f_p||^2 = 1/(2p) -> infinity,
    S_on = p/2 -> 0.

Thus one must NOT read N_1(0)=0 as an ordinary Neumann zero mode or count a constant profile as a physical normalizable field. The infimum of the zero-momentum extension energy with nonzero boundary value is zero, but it is not attained in the L2 solution space.

### Explicit essential-spectrum proof

Normalize a real window on [0,1] by

    h(s)=sqrt(8/3) sin^2(pi s),

and extend it by zero. It is C1 and H2, because h and h' vanish at both ends. This suffices for the Laplacian operator domain; smooth approximation is also available.

Its norms are

    ||h||^2=1,
    ||h'||^2=4 pi^2/3,
    ||h''||^2=16 pi^4/3.

Put a translated window far down the cusp:

    u_L(r)=L^-1/2 h((r-R_L)/L) exp(i k r),

with disjoint escaping supports, for example an integer sequence L=j and R_L=j^3 after discarding overlapping initial terms. Multiply by a normalized torus harmonic one-form and the parallel gauge coefficient.

Then ||u_L||=1, u_L converges weakly to zero, and

    ||(-d^2/dr^2-k^2)u_L||^2
      = 16 pi^4/(3 L^4) + 16 k^2 pi^2/(3 L^2) -> 0.

These are Weyl sequences for every k^2>=0. Hence [0,infinity) lies in the essential spectrum of this channel of the completed nonnegative operator. In particular there is no positive gap above zero in the full completion while this channel is retained.

Changing a compact interior or moving a cut cannot eliminate these sequences: their supports eventually avoid that entire region. This does NOT prove all continuum modes couple strongly to the proposed observed sector, nor that every effective theory is impossible. Such decoupling needs its own interaction calculation. It does prove that the compact source's discrete-spectrum argument and counts cannot be transferred to this completion merely by declaring the cut unphysical.

## 5. Nonlinear flag response: a quantitative condition on end integrability

Reuse the source identity rather than calling it a new theorem. Suppose the rank-five flat bundle has an invariant rank-four subbundle and a smooth harmonic metric on a core X0 and all its outward cusp extensions X_r. Let P be the metric-orthogonal projector, Xi=5P-4I, and beta the off-diagonal connection component. The source gives

    Phi(r) = integral_(Sigma_r) tr(Xi Psi_n)
           = -(5/2) integral_(X_r) |beta|^2.

For a nonsplit extension the core integral is nonzero. Therefore for some J0>0,

    Phi(r) <= -J0 <0

for every later cut. Also Xi has four eigenvalues +1 and one -4, so

    tr(Xi^2)=20.

Cauchy-Schwarz on Sigma_r gives

    integral_(Sigma_r) |Psi_n|^2
      >= Phi(r)^2/(20 Area(Sigma_r))
      >= J0^2/(20 A0) exp(2r/ell).

After radial integration,

    integral_(Y_[0,R]) |Psi|^2
      >= J0^2 ell/(40 A0) [exp(2R/ell)-1].

Therefore a smooth source-free harmonic continuation preserving this invariant extension cannot have finite integral |Psi|^2 on a complete shrinking cusp. The proof uses a single cusp exhaustion with no other physical boundary contribution. Additional ends, sources, topology, a changed field equation or altered asymptotics require their own accounting.

**This norm is harmonic-map/Hermitian-connection energy. It is NOT the physical potential**

    V = c integral (|F_D|^2+|mu|^2).

The original parent can have F_D=mu=0 without a finite integral |Psi|^2. Imposing the latter is an additional regularity/energy condition, not a criterion already derived from its residual action. Accordingly this is a restriction on a proposed finite-harmonic-norm completion, NOT a proof that the compact physical model is inconsistent or that every infinite-norm background has infinite physical energy.

### A sharp radial control retains this distinction

On a split block-diagonal exterior choose

    Xi=diag(1,1,1,1,-4),
    H_relative(r)=exp(alpha(r) Xi),
    alpha(r)=J0 ell/(20 A0) [exp(2r/ell)-1].

Then det H_relative=1. Its relative orthonormal-frame connection is

    C_r=Psi_r=-(alpha'/2) Xi.

It is flat and harmonic because alpha''-(2/ell)alpha'=0. Its outward flag current is exactly -J0, and its norm saturates the displayed lower bound. Thus the end equations can carry the current with increasingly extreme relative metric growth. Their residual potential is zero in this commuting control, even while the harmonic-map norm diverges.

This is a sharp scalar-current end control, NOT a complete silver extension: it does not match all matrix-valued normal data of the nonsplit core, its charged fermion domains, or every nonlinear boundary variation. It demonstrates why the two energy functionals must not be conflated and identifies the end behavior that a genuine completion would have to justify or exclude.

## 6. Symmetry inherited from the exterior constrains the response

Suppose a fixed unitary gauge action U preserves the exterior operator, metric and end prescription. Then uniqueness of its positive-frequency Poisson solution gives

    u_(Uf)=U u_f,
    N_Y U = U N_Y.

The same conclusion is immediate from the Gaussian Schur complement. This is not a statement about a phase or end state which already breaks U.

For an unbroken full SU5 fundamental or dual sector, Schur's lemma gives a response of the form identity_on_gauge tensor N_on_multiplicity. It cannot distinguish the color three and weak two by itself.

For example, a proposed selective response

    diag(kappa_c,kappa_c,kappa_c,kappa_w,kappa_w)

has commutator (kappa_c-kappa_w)E_i,alpha with an off-block gauge generator. It preserves the full group only when the two coefficients agree. If they differ, the traceless block stabilizer has dimension 12. This is a consequence of supplied selectivity, not a derivation of why a 3+2 split should occur.

The completed source's selective boundary explicitly prices such symmetry-breaking data. An actual Higgs/holonomy background already breaking SU5 is not refuted by this argument. Its own full operator response must be calculated; it cannot be replaced by the unbroken-symmetry conclusion or by assigned desired planes.

## 7. Input accounting and the narrower next test

| Item | Outcome in this gate |
|---|---|
| Arbitrary response at an artificial cut, once a complete exterior is fixed | Replaced by the exterior Dirichlet-to-Neumann/Poisson response; explicit in the tested channels. |
| Source's selective charged polarization L | NOT derived or replaced by the computed neutral/commuting channels. |
| Source's compact-domain spectrum transferred to the complete cusp | NOT valid without a new map; the retained q=1 channel has an essential threshold at zero. |
| Nonsplit extension with a finite harmonic-map-norm cusp | Incompatible under the stated global flag/exhaustion hypotheses. |
| Nonsplit compact parent or all conceivable ends | NOT excluded; the norm condition is not the bare physical action. |
| Matter/operator, parent, metric, exterior state and modular cusp unit | Still supplied/unselected. |

The useful implication is conditional:

    complete geometry + operator + end state
         -> boundary response at any artificial cut.

The missing upstream implication is still:

    record construction -> those physical data and their admissible state.

There is no newly retired foundational physical postulate in the source's completed selective model. The gate prevents counting a free response twice in a proposed complete realization and shows that the simplest unmodified cusp completion would change the physical problem substantially.

The next distinct physical task is to compute a boundary response from an actually justified interacting end or defect of the supplied parent, with its full real/fermion domain, while retaining the zero-threshold channels and the source flag-current balance. It must explain the symmetry-breaking data and address the continuum instead of selecting a favourable harmonic plane in advance. A local defect or core modification alone cannot remove escaping continuum modes in an otherwise unchanged cusp; changing their coupling to observations is a separate possible mechanism.

No new list of groups, dimensions, flux candidates or carrier census is needed. The measured success criterion remains retirement of a named input by an implication, not a preferred compatible example.

## 8. Executions and reproducibility

Run:

    python verify_exact.py
    python verify_reference.py --dps 50
    python verify_reference.py --dps 80

Dependencies: Python >=3.10, SymPy and mpmath. No network or repository imports are used.

- Primary: 50/50 exact checks, first execution exit 0.
- Separate Fraction method: 8/8 exact checks, repeated identically at both precisions.
- Numerical radial/variational method: 48/48 comparisons at 50 digits and 48/48 at 80 digits.
- Maximum normalized residual at 80 digits: 5.27109897161526e-81.

The two programs share an author. The numerical residuals are not interval-certified bounds. The Weyl sequence and nonlinear norm obstruction are analytic arguments with exact coefficient checks; the code is not a global PDE proof. The primary program, plan and subsequent reference program were hashed before their respective formal executions, after analytical exploration. No blind-preregistration claim is made. All three first executions passed and their logs remain unchanged.

## 9. Primary context and source separation

- Fork b7a51ac7, `reports/free_boundary_completion_2026_10_04/PROOF.md`, blob 3bc9f06bba87b566887631cbec0ff226af354ae0: inherited Jacobi, kinetic norm, free-boundary and energy distinctions.
- Same fork, `reports/silver_normal_response_2026_10_04/PROOF.md`, blob 588ab9e7c8aa75eeba41106ed35d163d87a06e75: inherited family and negative flag-current identity.
- Prior Joining Gate 1: coefficient and end distinction, not re-executed here.
- Kandel, Mnev, Wernli, arXiv:1912.11202v3, Sections 2 and 4, Appendix A: Gaussian response and gluing; their interacting two-dimensional theorem is not transferred to E8 by citation.
- Fichet, arXiv:2112.00746v2: boundary effective-action framework for specified backgrounds.
- Booß-Bavnbek, Lesch, Zhu, arXiv:0803.4160: first-order Calderon projections depend on the operator and geometric data; not a derivation of those data from the grammar.
- Wu, Zhang, arXiv:2109.01776v1, Proposition 3.3: compact Dirichlet harmonic-metric existence for supplied boundary data, not a complete-end theorem under arbitrary growth.

Novelty of the general gluing or cusp-spectral mechanisms is not claimed. This packet gives their explicit application and comparison, with their limits, to the source's specific record-to-boundary question.
