#!/usr/bin/env python3
"""Exact algebraic controls for the authored gate-2 comparison.
No source-repository producer is imported. These checks do not certify a
nonlinear E8 PDE or select a physical boundary. Python >=3.10, SymPy.
"""
from __future__ import annotations
import json
from pathlib import Path
import sympy as s

ROOT = Path(__file__).resolve().parent
checks: dict[str, bool] = {}
facts: dict[str, object] = {}

def zero(x):
    if isinstance(x, s.MatrixBase):
        return all(s.simplify(v) == 0 for v in x)
    return s.simplify(x) == 0

def check(name: str, condition):
    ok = bool(condition)
    checks[name] = ok
    if not ok:
        raise AssertionError(name)

def schur(mat, keep):
    rest = [j for j in range(mat.rows) if j not in keep]
    a,b,c = mat.extract(keep,keep),mat.extract(keep,rest),mat.extract(rest,rest)
    return (a-b*c.inv()*b.T).applyfunc(s.factor)

# 1. Positive Gaussian elimination includes the determinant and is associative.
R = s.Matrix([[2,1,0,1,0],[0,2,1,0,1],[1,0,3,1,0],[0,1,1,2,1],[1,0,0,1,2]])
H = R.T*R+s.eye(5)
A,B,C=H[:2,:2],H[:2,2:],H[2:,2:]
K=A-B*C.inv()*B.T
x=s.Matrix(s.symbols('x0:2'));y=s.Matrix(s.symbols('y0:3'))
v=x.col_join(y); ys=y+C.inv()*B.T*x
check('gaussian_completion_of_squares',zero((v.T*H*v)[0]-(x.T*K*x)[0]-(ys.T*C*ys)[0]))
check('gaussian_determinant_retained',zero(H.det()-C.det()*K.det()))
check('gaussian_boundary_covariance',zero(H.inv()[:2,:2]-K.inv()))
check('gaussian_positive_bulk',all(H[:j,:j].det()>0 for j in range(1,6)))
check('gaussian_positive_response',K[0,0]>0 and K.det()>0)
Kstage=schur(H,[0,1,2]);Kseq=schur(Kstage,[0,1])
check('successive_exterior_elimination_equals_direct',zero(Kseq-K))
wrong=A+B*C.inv()*B.T
check('wrong_schur_sign_detected',not zero(wrong-K))
# Homogeneous unanchored chain: neither a cut nor elimination creates a mass.
L=s.Matrix([[1,-1,0],[-1,2,-1],[0,-1,1]])
check('massless_chain_constant_kernel',L.rank()==2 and L*s.ones(3,1)==s.zeros(3,1))
check('massless_chain_no_spurious_boundary_mass',zero(schur(L,[0])))
anch=L+s.diag(0,0,1)
check('anchored_far_end_changes_response',schur(anch,[0])[0]==s.Rational(1,3))
facts['gaussian_response_example']=str(K)

# 2. Exact interval gluing, rational in exp(p*length), no numeric tolerance.
p,r1,r2,beta=s.symbols('p r1 r2 beta',positive=True)
def slab(r):
    return p/(r*r-1)*s.Matrix([[r*r+1,-2*r],[-2*r,r*r+1]])
K1,K2=slab(r1),slab(r2)
joined=s.zeros(3)
for ix in range(2):
    for jx in range(2):
        joined[ix,jx]+=K1[ix,jx]
        joined[ix+1,jx+1]+=K2[ix,jx]
check('exact_slab_sewing',zero(schur(joined,[0,2])-slab(r1*r2)))
term=K1[0,0]-K1[0,1]**2/(K1[1,1]+p)
check('transparent_end_is_cut_independent',zero(term-p))
generic=s.factor(K1[0,0]-K1[0,1]**2/(K1[1,1]+beta))
check('other_end_response_changes_answer',not zero(generic-p))
check('zero_termination_differs_from_transparent',not zero(generic.subs(beta,0)-p))
facts['terminated_slab_response']=str(generic)

# 3. Actual warped cusp radial form weights and Dirac square.
r,ell,a,nu=s.symbols('r ell a nu',real=True, positive=True)
q=s.symbols('q',integer=True)
check('cusp_form_weight',zero(s.exp(2*q*r/ell)*s.exp(-2*r/ell)-s.exp(2*(q-1)*r/ell)))
f=s.Function('f')(r);u=s.Function('u')(r)
w=s.exp(-2*a*r)
P=-s.diff(w*s.diff(f,r),r)/w
check('weighted_radial_operator',zero(P-(-s.diff(f,r,2)+2*a*s.diff(f,r))))
fu=s.exp(a*r)*u
check('unitary_radial_potential',zero((-s.diff(fu,r,2)+2*a*s.diff(fu,r))/s.exp(a*r)-(-s.diff(u,r,2)+a*a*u)))
k=s.symbols('k',real=True)
Q=s.Matrix([[0,a-s.I*k],[a+s.I*k,0]])
check('radial_Dirac_Hermitian',Q.conjugate().T==Q)
check('radial_Dirac_square',zero(Q*Q-(a*a+k*k)*s.eye(2)))
profile=s.exp((a-nu)*r)
check('exterior_profile_solves_equation',zero(-s.diff(profile,r,2)+2*a*s.diff(profile,r)+(nu*nu-a*a)*profile))
check('exterior_response_from_normal_derivative',zero(-s.diff(profile,r).subs(r,0)-(nu-a)))
energy=((a-nu)**2+nu**2-a**2)/(2*nu)
check('on_shell_action_boundary_coefficient',zero(energy-(nu-a)))
check('Robin_root_equation',zero((nu-a)**2+2*a*(nu-a)-(nu**2-a**2)))
check('q1_response_p',zero((nu-a).subs({a:0,nu:p})-p))
check('q0_static_constant_allowed',zero((nu-a).subs(nu,a)))
# q=2 has a=-1/ell: use a separate substitution because a declared positive.
aa=s.symbols('aa',real=True)
check('q2_static_tangential_response',zero((s.sqrt(aa**2)-aa).subs(aa,-1/ell)-2/ell))
P2=s.symbols('P2')
series=s.series(s.sqrt(ell**-2+P2)-1/ell,P2,0,3).removeO()
check('q0_low_frequency_series',zero(series-(ell*P2/2-ell**3*P2**2/8)))
check('discarding_cusp_weight_is_detected',not zero((-s.diff(profile,r,2)+(nu**2-a**2)*profile)))
# A concrete finite-energy cut-off sequence at the q=1 zero threshold.
t=s.symbols('t',real=True)
h=s.sqrt(s.Rational(8,3))*s.sin(s.pi*t)**2
n0=s.integrate(h*h,(t,0,1));n1=s.integrate(s.diff(h,t)**2,(t,0,1));n2=s.integrate(s.diff(h,t,2)**2,(t,0,1))
check('Weyl_window_normalization',n0==1)
check('Weyl_window_first_norm',n1==4*s.pi**2/3)
check('Weyl_window_second_norm',n2==16*s.pi**4/3)
check('Weyl_window_H2_zero_extension',all(v==0 for v in [h.subs(t,0),h.subs(t,1),s.diff(h,t).subs(t,0),s.diff(h,t).subs(t,1)]))
length=s.symbols('length',positive=True)
wave=s.exp(s.I*k*length*t)*h
residual=-s.diff(wave,t,2)/length**2-k*k*wave
expected=s.exp(s.I*k*length*t)*(-s.diff(h,t,2)/length**2-2*s.I*k*s.diff(h,t)/length)
check('all_wave_numbers_Weyl_residual',zero(residual-expected))
check('Weyl_residual_norm_cross_term_zero',zero(s.expand_complex((expected*s.conjugate(expected)))-s.diff(h,t,2)**2/length**4-4*k*k*s.diff(h,t)**2/length**2))
facts['Weyl_residual_squared']=str(n2/length**4+4*k*k*n1/length**2)
# q=1 p=0 harmonic solution A+Br has no nonzero L2 function.
# This is proved in the report, not encoded as a numerical cutoff assertion.

# 4. Flag-current lower bound, exact saturating radial tail, correct norm.
A0,J0,Rend=s.symbols('A0 J0 Rend',positive=True)
Xi=s.diag(1,1,1,1,-4)
check('rank5_flag_trace_zero',s.trace(Xi)==0)
check('rank5_flag_squared_norm',s.trace(Xi*Xi)==20)
area=A0*s.exp(-2*r/ell)
Iinv=s.integrate(1/area,(r,0,Rend))
check('inverse_area_integral',zero(Iinv-ell/(2*A0)*(s.exp(2*Rend/ell)-1)))
# Signed current Phi=-J0; H=exp(alpha Xi), C_r=-alpha' Xi/2.
alpha=J0*ell/(20*A0)*(s.exp(2*r/ell)-1)
psi=-s.diff(alpha,r)*Xi/2
check('sharp_tail_current',zero(area*s.trace(Xi*psi)+J0))
check('sharp_tail_harmonic_radial_equation',zero(s.diff(alpha,r,2)-2/ell*s.diff(alpha,r)))
check('sharp_tail_trace_density',zero(area*s.trace(psi*psi)-J0**2/(20*area)))
check('sharp_tail_norm_integral',zero(s.integrate(area*s.trace(psi*psi),(r,0,Rend))-J0**2*ell/(40*A0)*(s.exp(2*Rend/ell)-1)))
check('sharp_tail_metric_determinant',zero(s.exp(alpha)**4*s.exp(-4*alpha)-1))
check('flux_bound_diverges',s.limit(J0**2*ell/(40*A0)*(s.exp(2*Rend/ell)-1),Rend,s.oo)==s.oo)
# With flat radial C and harmonic alpha, physical curvature/moment residuals
# vanish: the harmonic-map norm must NOT be relabelled the residual potential.
check('nonzero_norm_zero_radial_moment',not zero(psi) and zero(s.diff(psi,r)-2*psi/ell))
check('wrong_shrinking_area_sign_changes_bound',not zero(s.integrate(s.exp(-2*r/ell)/A0,(r,0,Rend))-Iinv))

# 5. A response cannot break an exact symmetry of its exterior.
cc,cw=s.symbols('cc cw',real=True)
Ks=s.diag(cc,cc,cc,cw,cw)
E=s.zeros(5);E[0,3]=1
check('selective_response_requires_broken_generator',zero(Ks*E-E*Ks-(cc-cw)*E))
check('common_response_full_gauge_invariant',zero((Ks*E-E*Ks).subs(cw,cc)))
count=sum(1 for i in range(5) for j in range(5) if (i<3)==(j<3))-1
check('selective_traceless_commutant_dimension',count==12)
# Explicit block Gaussian elimination commutes with the complete gauge action.
small=s.Matrix([[3,-1,-1],[-1,4,-1],[-1,-1,3]])
smallK=schur(small,[0,1])
full=s.kronecker_product(small,s.eye(5))
resp=schur(full,list(range(10)))
check('elimination_retains_full_gauge_factor',zero(resp-s.kronecker_product(smallK,s.eye(5))))
G=s.kronecker_product(s.eye(2),E)
check('actual_response_gauge_commutator',zero(resp*G-G*resp))

out={'status':'PASS','check_count':len(checks),'checks':checks,'facts':facts,
     'scope':'exact finite controls and radial identities; no global E8 PDE, selected boundary, or quantum anomaly certificate'}
(ROOT/'EXACT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
