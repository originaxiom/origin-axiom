# Joining Gate 2: seam response and the complete-cusp test

Read TECHNICAL_REPORT.md for the authored conditional argument and its explicit failure boundaries. This is not a full joining of the record principle to a selected physical theory.

## Reproduce

Python >=3.10 with sympy and mpmath:

```
python verify_exact.py
python verify_reference.py --dps 50
python verify_reference.py --dps 80
```

Expected: 50 exact primary checks, 8 separate Fraction checks, and 48 numerical comparisons at each precision. Original first logs and outputs are retained. No source scientific code is imported, no models are trained and no remote write is made. The scripts use the same author and are not independent external review.

The strongest positive is an explicit exterior response replacing an arbitrary seam law in controlled physical form channels. The most important caution is that the resulting complete cusp has zero-threshold continuum modes; its domain is not the source's selective compact boundary. A separate flag-current bound rules out finite harmonic-map norm under its stated continuation hypotheses, not finite bare parent residual energy.
