#!/usr/bin/env python3
"""Separate Fraction elimination and high-precision radial checks.
Does not import the primary verifier or repository code. The constructions
share an author. Numerical residuals are not certified interval bounds.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import argparse,json
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def transpose(a): return [list(x) for x in zip(*a)]
def mul(a,b): return [[sum((x*y for x,y in zip(r,c)),F(0)) for c in zip(*b)] for r in a]
def add(a,b,sign=1): return [[x+sign*y for x,y in zip(r,s)] for r,s in zip(a,b)]
def inv(a):
    n=len(a); w=[[F(x) for x in row]+[F(i==j) for j in range(n)] for i,row in enumerate(a)]
    for j in range(n):
        pivot=next(i for i in range(j,n) if w[i][j])
        w[j],w[pivot]=w[pivot],w[j]
        q=w[j][j];w[j]=[x/q for x in w[j]]
        for i in range(n):
            if i!=j:
                q=w[i][j];w[i]=[x-q*y for x,y in zip(w[i],w[j])]
    return [r[n:] for r in w]
def det(a):
    n=len(a);w=[[F(x) for x in r] for r in a];out=F(1)
    for j in range(n):
        opts=[i for i in range(j,n) if w[i][j]]
        if not opts:return F(0)
        i=opts[0]
        if i!=j:w[i],w[j]=w[j],w[i];out=-out
        pivot=w[j][j];out*=pivot
        for i in range(j+1,n):
            q=w[i][j]/pivot
            for k in range(j+1,n):w[i][k]-=q*w[j][k]
    return out
def sub(a,r,c):return [[a[i][j] for j in c] for i in r]
def schur(a,keep):
    rest=[i for i in range(len(a)) if i not in keep]
    A,B,C=sub(a,keep,keep),sub(a,keep,rest),sub(a,rest,rest)
    return add(A,mul(mul(B,inv(C)),transpose(B)),-1)

def run(dps):
    mp.mp.dps=dps; exact={};num=[]
    def ec(name,value):
        exact[name]=bool(value)
        if not value:raise AssertionError(name)
    def nc(name,left,right,tol=None):
        residual=abs(left-right)/max(mp.mpf(1),abs(left),abs(right))
        threshold=mp.power(10,-dps+12) if tol is None else tol
        ok=bool(residual<threshold)
        num.append({'name':name,'residual':mp.nstr(residual,15),'passed':ok})
        if not ok:raise AssertionError((name,mp.nstr(residual)))
    R=[[2,1,0,1,0],[0,2,1,0,1],[1,0,3,1,0],[0,1,1,2,1],[1,0,0,1,2]]
    H=mul(transpose(R),R)
    for i in range(5):H[i][i]+=1
    K=schur(H,[0,1]);C=sub(H,[2,3,4],[2,3,4])
    ec('Fraction_response_matches_direct_algebra',K==[[F(1755,353),F(151,353)],[F(151,353),F(1850,353)]])
    ec('Fraction_determinant_factorization',det(H)==det(C)*det(K))
    ec('Fraction_boundary_covariance',sub(inv(H),[0,1],[0,1])==inv(K))
    ec('Fraction_associative_elimination',schur(schur(H,[0,1,2]),[0,1])==K)
    for i,(p,a,b) in enumerate([(F(5,7),F(2),F(3)),(F(3,2),F(4),F(5))]):
        def slab(r):return [[p*(r*r+1)/(r*r-1),-2*p*r/(r*r-1)],[-2*p*r/(r*r-1),p*(r*r+1)/(r*r-1)]]
        ka,kb=slab(a),slab(b);j=[[F(0)]*3 for _ in range(3)]
        for r in range(2):
            for c in range(2):j[r][c]+=ka[r][c];j[r+1][c+1]+=kb[r][c]
        ec('Fraction_seam_'+str(i),schur(j,[0,2])==slab(a*b))
        ec('Fraction_transparent_cap_'+str(i),ka[0][0]-ka[0][1]**2/(ka[1][1]+p)==p)
    # Weighted half-line variational energy against boundary derivative.
    for ell in (mp.mpf(1),mp.mpf('1.5')):
        for q in range(3):
            for p in (mp.mpf('.3'),mp.mpf('1.2')):
                a=(1-q)/ell;om=mp.sqrt(a*a+p*p)
                f=lambda r:mp.exp((a-om)*r)
                weight=lambda r:mp.exp(-2*a*r)
                deriv=lambda r:mp.diff(f,r)
                integrand=lambda r:weight(r)*(deriv(r)**2+p*p*f(r)**2)
                E=mp.quad(integrand,[0,1,5,mp.inf])
                tag=f'{ell}_{q}_{p}'
                nc('energy_vs_DtN_'+tag,E,om-a)
                rr=mp.mpf('.71')
                nc('weighted_ODE_'+tag,-mp.diff(f,rr,2)+2*a*mp.diff(f,rr)+p*p*f(rr),0)
                nc('boundary_derivative_'+tag,-mp.diff(f,0),om-a)
    # Nonzero torus-frequency scalar channel: Bessel solution.
    for ell,k,p in ((mp.mpf(1),mp.mpf('.7'),mp.mpf('.3')),(mp.mpf('1.5'),mp.mpf('1.1'),mp.mpf('1.2'))):
        a=1/ell;nu=mp.sqrt(1+(ell*p)**2);z0=k*ell
        f=lambda r:mp.exp(a*r)*mp.besselk(nu,z0*mp.exp(r/ell))/mp.besselk(nu,z0)
        Kp=-a+z0/(2*ell)*(mp.besselk(nu-1,z0)+mp.besselk(nu+1,z0))/mp.besselk(nu,z0)
        tag=f'{ell}_{k}_{p}'
        nc('Bessel_normalization_'+tag,f(0),1)
        nc('Bessel_DtN_independent_derivative_'+tag,-mp.diff(f,0),Kp)
        for r in (mp.mpf('.2'),mp.mpf('.8')):
            nc('Bessel_radial_ODE_'+tag+'_'+str(r),-mp.diff(f,r,2)+2*a*mp.diff(f,r)+(p*p+k*k*mp.exp(2*r/ell))*f(r),0)
        if Kp<=0:raise AssertionError('Bessel response not positive')
    # Direct integration of escaping radial wave packets, not a spectrum grid.
    h=lambda x:mp.sqrt(mp.mpf(8)/3)*mp.sin(mp.pi*x)**2
    n0=mp.quad(lambda x:h(x)**2,[0,1])
    n1=mp.quad(lambda x:mp.diff(h,x)**2,[0,1])
    n2=mp.quad(lambda x:mp.diff(h,x,2)**2,[0,1])
    nc('window_L2',n0,1);nc('window_derivative',n1,4*mp.pi**2/3);nc('window_second_derivative',n2,16*mp.pi**4/3)
    # Sharp flag-current radial control by direct quadrature.
    ell,A0,J0,T=mp.mpf('1.4'),mp.mpf('2.3'),mp.mpf('.8'),mp.mpf('1.1')
    alph=lambda r:J0*ell/(20*A0)*(mp.exp(2*r/ell)-1)
    area=lambda r:A0*mp.exp(-2*r/ell)
    density=lambda r:5*area(r)*mp.diff(alph,r)**2
    nc('sharp_flux_quadrature',mp.quad(density,[0,T]),J0**2*ell/(40*A0)*(mp.exp(2*T/ell)-1))
    out={'precision_digits':dps,'exact_checks':exact,'exact_count':len(exact),'numerical_count':len(num),
         'max_normalized_residual':mp.nstr(max(mp.mpf(x['residual']) for x in num),20),'numerical_checks':num,
         'status':'PASS','scope':'same-author different-method controls; no interval certification or E8 PDE solve'}
    (ROOT/f'REFERENCE_{dps}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--dps',type=int,default=50);args=ap.parse_args();run(args.dps)
