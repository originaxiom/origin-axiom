# Joining gate 2 — eliminate an artificial seam before selecting a boundary

Date: 2026-10-11. This plan is written after source reading and analytical exploration, before executing the new verification programs. It is NOT a blind preregistration, independent timestamp, or repository commit.

## Fixed task
Test whether the end response can be inferred rather than supplied in the same record-to-physical-model joining problem. Do not assign the selective physical boundary to new fields by hand. Do not equate an auxiliary harmonic-metric energy with the parent residual potential.

## Source boundary
Predecessor: Joining Gate 1. Fork b7a51ac7094ea5b1e800598238a51890d9345dfc supplies the compact harmonic metric, Jacobi operator and negative flag-response identity. Its free_boundary_completion and silver_normal_response proofs already contain Dirichlet-to-Neumann kinetic norms, free-boundary degeneracy and a response expansion; these are PRIOR work. Physical head cba986752e8c1b5c49f70c91909d4aa869886ded seals charged cubic work but is not a completed charged-cubic result. No such producer is rerun here. Searches of the default branch are not all-branch novelty evidence.

## Explicit additional comparison
Replace a finite artificial cut by a specified complete hyperbolic cusp. Keep a globally parallel compact gauge coefficient in the surviving centralizer, so the scalar/form quadratic channels really occur in the supplied Hodge/Weyl parent. Cusp metric and complete/no-added-source end prescription are additional comparison hypotheses, NOT derived by the record principle, and NOT silently identified with the source's selective compact boundary.

## Questions and criteria
1. Derive a response from elimination of the exterior in a positive Gaussian system. Verify Schur complement, inverse, determinant and successive elimination; include wrong-sign controls. The determinant is part of quantum gluing but its ultraviolet renormalization is not solved.
2. Compute complete-cusp harmonic tangential q-form channels q=0,1,2. Derive the weighted operator, unitary radial Dirac block and finite-action/L2 response for positive Euclidean spectral parameter. Treat the p=0 threshold separately.
3. For the physical q=1 parallel-coefficient sector construct actual escaping Weyl sequences. Determine whether the completed operator has a gap. Do not turn absence of a gap into a universal impossibility of an effective theory; coupling/decoupling remains a separate problem.
4. Verify exact one-dimensional seam composition, including the response of a terminated slab. A hand-chosen Robin law is a different model unless it equals the actual exterior response.
5. Apply the source's rank-five flag identity to a putative smooth harmonic continuation. Derive the quantitative lower bound on integral |Psi|^2 in a shrinking cusp. This norm is NOT the physical residual potential. A failure of this integrability test is not a no-go against every allowed physical end.
6. Exhibit the commuting end profile saturating the scalar-current bound. It is a tail control, not a solution of the entire silver gluing problem. Preserve the possibility of zero residual potential with divergent harmonic-map norm.
7. If the exterior and its state preserve full gauge SU5, prove its linear response is gauge-equivariant. A color/weak-selective operator requires symmetry-breaking data; a phase that already has such data is outside that restricted obstruction.

## What would count as input retirement
A response at an artificial cut is not an independent input once the complete exterior operator, metric and end state are fixed. This does NOT retire the programme's physical parent, selective charged polarization, nonzero extension or modular cusp integer. Full success would additionally derive those exterior data from the records and show their response agrees with the actual physical domain.

## Outputs
Self-contained proofs, two verification methods, raw outputs, commands, file hashes and input provenance. Preserve every failed formal execution and repair. Do not push or change remote files in this task. No new particle census, source PDE solve, model selection or gravity claim.
