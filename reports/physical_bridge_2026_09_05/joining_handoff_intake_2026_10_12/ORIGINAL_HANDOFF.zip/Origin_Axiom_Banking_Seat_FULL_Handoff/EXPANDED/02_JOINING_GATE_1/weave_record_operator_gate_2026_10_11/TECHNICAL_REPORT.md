# Joining gate 1 — record information, the actual coefficient, and the end law

**Date:** 11 October 2026.  
**Task:** test an explicit implication connecting the record construction to the existing physical model, not construct another unrelated model.  
**Disposition:** one exact obstruction to a compressed-data bridge; a reproduced conditional coefficient-uniqueness result; no new physical-input elimination.  
**Evidence:** 57 primary exact checks and 17 same-author separate-method checks. These are finite algebra, not a global PDE or quantum certificate.

## Executive result

The record's quaternion cohomology and lifted move action are not sufficient information to reconstruct the particular flat coefficient used by the silver physical model. A specific 54-letter word is invisible to every quaternion doublet cocycle, but is detected by the physical coefficient and by the full E8 adjoint character under the existing parent embedding. Thus a proposed joining map cannot simply identify the finite triplet, or its known weaker algebraic carrier, with this physical coefficient.

A fuller geometric route does give a useful conditional implication. On the pinned m135 carrier and parity character, the rank-four coefficient has two-dimensional ordinary H1 but only one-dimensional interior H1. Requiring a rank-five nonsplit extension to introduce no new peripheral extension transport selects one nonzero projective extension class. The recorded cocycle lies in it. This conditional construction was already proved in the repository; the present work verifies its actual rank-four input and uses it to locate, rather than rename, the remaining assumptions.

The conclusions do not derive m135, its sign/parity, the nonzero rather than split extension, a positive kinetic metric, an E8 parent, Lorentz interpretation, a physical fermion domain, the selective weak/color polarization, or one unit on the modular cusp. Consequently **no previously supplied foundational physical input has been shown to cease being independent in this gate**. The projective matrix lift and cocycle coordinates are redundant mathematical presentation data in the stated construction. They are not the missing physical selection law.

## 1. Current sources and the actual question

The live branch read returned main at `6c148ddd495d133213140995976ff08849793d5d`, the foundational audit at `b7a51ac7094ea5b1e800598238a51890d9345dfc`, and the physical branch at `feb9d8d0308bea654f6d80bbc6c3ab0efd83ee8e`. These are the pinned snapshot, not a claim to see unpublished work.

At the new physical pin the selective-boundary proposal has become a completed *conditional* checkpoint: its report gives one family, a weak-doublet pair, seven neutral chiral multiplets and twelve vectors on an explicitly new supplied boundary. That advances downstream admission, not the upstream selection tested here. Its parent and boundary data were not recomputed or adopted as generated inputs.

The current foundational `UPSTREAM_DEPENDENCIES.md` asks for exactly the distinction examined here: how much of the record survives in a specified coefficient, and what extra information is needed by a physical operator and its end law. Its `cohomology_carrier/PROOF.md` supplies the quotient F/F''' that retains all quaternion H1 and move data. Its puncture proof expressly separates local coefficients, a grading, operator domains and the rank-five silver parent.

The m135 input is copied from `silver_operator_gate_2026_10_05/candidate.json`. Its 640 bytes reproduce Git blob `e1e4b140bc27df46d9bc41bfdfebf8464b17fa2d` exactly. The producer was read to identify the representation and conventions but was NOT imported or executed. No all-branch absence or novelty claim follows from the targeted searches.

This is a **thread-specific diagnostic**. The input is the signed thread `-LLRR`, not a demonstration that the ruled positive-move weave selects it. A single such example can refute a universal compressed-data implication; it cannot establish a universal physical construction.

## 2. Reconstruct the physical coefficient without fitting its entries

Write Gamma for the marked group

    <a,b,t | taTbba, tbTbbabbab>,

where uppercase denotes inverse. The two peripheral words are `abAB` and `abt`. The source parity is nu(a)=1, nu(b)=-1, nu(t)=-1. Its projective two-by-two holonomies are recorded in `candidate.json`.

For any nonsingular complex matrix M define the real-linear action on Hermitian matrices

    R(M)(X) = M X M^dagger / |det M|.

It composes: R(MN)=R(M)R(N). More importantly, R(z M)=R(M) for every nonzero complex scalar z. Thus this coefficient does not need a choice of SL2 square root, central spin sign, or projective matrix scale. It preserves det(X), an indefinite quadratic form of Lorentzian signature. This is the standard Hermitian-matrix representation, not a derivation that its four entries are physical spacetime.

The actual coefficient is V(g)=nu(g) R(M_g). A real Hermitian basis gives 4-by-4 matrices over Q(sqrt(2)); its complexification is the rank-four coefficient used by the parent. The two relators, determinant-one condition, and invariant indefinite form were checked exactly. A second construction uses row vectorization and the Kronecker product M tensor conjugate(M).

For generator a the exact characteristic polynomial is

    det(x I - V(a)) = (x^2+1)(x^2-2 sqrt(2) x+1).

Its eigenvalues are i, -i, sqrt(2)+1 and sqrt(2)-1. Consequently it is neither finite-image nor unitarizable by a constant positive Hermitian metric. If H>0 and V(a)^dagger H V(a)=H, an eigenvector with eigenvalue lambda would have |lambda|^2 ||v||_H^2=||v||_H^2. The eigenvalue sqrt(2)+1 violates this.

This does NOT contradict the physical branch's positive harmonic metric. That metric varies over the base and is not a parallel positive metric for the original nonunitary holonomy. It does show that averaging an inner product over a finite quaternion group cannot supply the required physical harmonic metric unchanged.

A flat coefficient obtained solely by sums, tensors, duals and subquotients from a finite-image representation still has finite image. It cannot be V or its rank-five extension. The groups acting on record moves and on loops must not be confused: this is a statement about any proposed pullback/factorization to the actual loop group, not an identification of those groups.

## 3. An exact information-loss witness beyond the finite-image observation

Let F=F(a,b), and set

    c=[a,b], r=[c,a c a^-1], w=[r,a r a^-1].

These are precisely the nested words used by the foundational quotient proof. By construction r belongs to F'' and w to F'''. The freely reduced w has length 54:

    abABaabABAbaBaabABAbaaBAbAABabaBAAbaBaabAABabaBAAbaBAA

Two reduction procedures agree on it. The elementary quotient F/F''' identifies w with the identity. This is a signed loop in the chosen spatial fundamental group, not an assertion that inverse letters must be admitted as legal record-update events. Those two uses of words remain distinct.

For rho_Q(a)=diag(i,-i), rho_Q(b)=[[0,1],[-1,0]], every parity-twisted quaternion representation satisfies rho_Q(w)=I. More strongly, for arbitrary cocycle values z(a),z(b), the linear evaluation z(w) is identically zero. The verifier computes the complete 2-by-4 symbolic evaluation matrix, rather than sampling chosen cocycles, for all four parity twists. The second-derived word r has nonzero evaluation rank two and is an opposing control.

This agrees with, and does not replace, the source's all-word theorem: a cocycle gives an affine representation into V semidirect Q8, whose derived length is at most three; every such cocycle therefore descends to F/F'''. The six-dimensional H1 and the lifted move representation are preserved by that quotient.

For the ACTUAL m135 projective spinor matrices, direct exact word multiplication instead gives

    det M(w)=1,
    tr M(w)=-50,331,646 + 2,097,152 i.

Hence

    tr V(w)=|tr M(w)|^2=2,537,672,635,580,420 != 4.

The reference calculation obtains the same result using pairs of Python Fractions for Gaussian numbers, without SymPy matrix multiplication in this word calculation. The primary method additionally multiplies the rank-four matrices directly.

This is an exact distinction between two mathematical data sets, not a tiny numerical discrepancy. The large trace is not an energy, a mass or a hierarchy prediction.

### It survives the full-parent test

A defining-coefficient trace alone is not automatically a full E8 invariant. Here the calculation concerns the complexified flat background connection A+iB, not the unitary holonomy of the compact gauge connection A alone or an experimentally measured Wilson loop. Using the source's already established branching

    248=(24,1)+(1,24)+(10,5)+(bar10,bar5)+(5,bar10)+(bar5,10),

the structure-only adjoint character is

    24 + tr(W)tr(W^-1)-1
       +10[tr(W)+tr(W^-1)]
       +5[tr(Lambda2 W)+tr(Lambda2 W^-1)].

For the word above it is exactly

    6,439,782,405,373,806,910,005,477,114,104,

rather than 248. Direct rank-five/exterior-square traces agree with a separate spinor-character formula. At the identity both formulas return 248. This uses the supplied E8 embedding and branching; it does not derive them from the records.

**Conclusion:** the physical coefficient and its parent holonomy do not descend through the retained quotient F/F'''. Therefore no joining map that factors only through those compressed quaternion/cohomology data can reconstruct this particular connection. The original positive quotient theorem remains correct within its scope. The counterexample does not rule out the record triplet as a sector of another model, or force full faithful F2 for every conceivable physical observable. It identifies a specific additional signed distinction read by this model.

## 4. A constructive conditional implication at the extension step

The rank-five coefficient has form

    W_z(g) = [[V(g), z(g)], [0,1]],

where z(gh)=z(g)+V(g)z(h). Changing a splitting adds the coboundary (V(g)-I)b. Thus extension classes are H1(Gamma,V).

Let B stack V(g)-I, let F1 be the two-relator evaluation map, and let R evaluate cocycles on the two peripheral words. Let D_boundary stack V(p)-I for those peripheral words. The exact ranks over Q(sqrt(2)) are

    rank B = 4,
    rank F1 = 6,
    rank D_boundary = 3,
    rank [[F1,0],[R,-D_boundary]] = 10.

Therefore

    dim H1(Gamma,V)=12-6-4=2,
    dim ker[H1(Gamma,V) -> H1(boundary,V)]
       =12-4-10+3=1.

The given cocycle has F1 z=0, raises rank[B|z] to five, and Rz lies in im D_boundary. It is a nonzero member of this one-dimensional interior class.

The full H1 has an additional independent direction. `MATRICES.json` supplies an explicit other cocycle: it is closed and not a coboundary, but its peripheral class is nonzero. Requiring merely the bulk relators does NOT select the recorded ray.

### What unchanged peripheral transport actually fixes

If Rz=D_boundary b, replacing z by z-Bb kills BOTH peripheral cocycles using one common change of splitting. This was checked on the full rank-five peripheral matrices, not only on cohomology dimensions. Thus the restricted extension is literally split in that frame.

Every nonzero class with this property is lambda[z]. Triangular changes of splitting and diag(lambda I4,1) identify the corresponding abstract representations for lambda!=0. Over C the conjugator can also be made determinant one by a common scalar without changing its conjugation action. The exact zero class remains different: it has one invariant scalar, whereas the pinned nonsplit coefficient has no invariant scalar.

The conditional implication is consequently

    chosen marked carrier and geometric V
    + nonzero extension
    + no additional peripheral extension transport
      => one rank-five extension isomorphism class.

The repository's October 4 `silver_boundary_admission/PROOF.md` already gives this construction in its 'Exact implementation and cocycle gauge' section. It is credited, not announced as a new theorem. The present calculation verifies the rank-four hypotheses at the actual pinned input and places this implication at its proper point in the joining test.

This removes the need to treat the twelve displayed cocycle coordinates, or their representative/splitting, as twelve independent algebraic inputs. It does not remove the nonzero-extension or end-preservation conditions themselves.

The split alternative is not a commuting or empty record system: it retains the identical geometric V, and rank([V(a),V(b)]_group-I)=2. Thus the nonzero extension cannot be selected merely by renaming the original noncommutation requirement as a demand for nonsplitting. The latter is a different property. This additional control was evaluated from the primary exact matrices after their main checks and is recorded separately in SPLIT_CONTROL.json.

## 5. An algebraic normalization is not a physical normalization

For nonzero lambda,

    W_(lambda z)=S_lambda W_z S_lambda^-1,
    S_lambda=diag(lambda I4,1).

S_lambda is generally nonunitary. If a Hermitian metric is simultaneously transported, this is a change of description. If the physical boundary/kinetic metric is held fixed, it need not be an allowed compact gauge change.

For an explicit fixed identity metric at a reference fibre, the sum of the three generator Hilbert-Schmidt norm squares changes between z and 2z by

    3 sum_g ||z(g)||^2 = 798+108 sqrt(2) > 0.

That norm is invariant under simultaneous unitary conjugation, so the two triples are not unitarily conjugate in this control metric. This does not assert that the identity metric is the actual globally harmonic metric of the silver background. It demonstrates why GL-equivalence alone cannot remove a physical kinetic-normalization input.

Similarly, scaling a supplied internal Riemannian metric by r^2 preserves its flat connection and cohomology but rescales the Hodge Laplacian by r^-2 after the standard unitary identification of form spaces. It changes a dimensionful mass scale. This does not by itself exclude dimensionless predictions; it shows why a chosen flat coefficient does not determine all spectral data.

## 6. Unchanged puncture holonomy does NOT mean zero physical boundary response

The same predecessor contains a crucial further implication. For a harmonic metric on a nonsplit rank-five extension, let P be the metric-orthogonal projector onto the invariant rank-four subbundle, xi=5P-4I, and eta the off-diagonal connection component. In its conventions,

    integral_X tr(xi I)
      =5 integral_X |eta|^2 + 2 integral_boundary tr(xi Psi_n),
    I=-2 d_A^*Psi.

Harmonicity makes I=0. Nonsplitting makes eta nonzero. Therefore

    integral_boundary tr(xi Psi_n)
      =-(5/2) integral_X |eta|^2 < 0.

This is SOURCE-DERIVED, not newly recomputed here. The source identifies it as a necessary balance rather than a law selecting the boundary data.

It clarifies the target considerably. The extension can leave the peripheral monodromy split while requiring a nonzero real structure-sector response at the boundary. The two statements concern different data. This response is neither the parallel gauge projection Pi_k nor the integer n at the modular cusp. Equating them from their signs or nonzero values would be another unproved map.

The flux sign is no longer arbitrary once this nonsplit harmonic solution is specified. But the choice of the nonzero extension and the positive boundary metric remains supplied. This inherited implication does not constitute a newly derived foundational end law.

## 7. A direct demonstration that the physical domain is not selected yet

The existing same-parent multiplet report already gives two admissible harmonic-polarization choices on the same coefficient/background:

    (ell_W,ell_F)=(2,3) => (J_W,J_F)=(0,0),
    (ell_W,ell_F)=(3,4) => (J_W,J_F)=(1,1).

Both obey the local SU5 cubic anomaly condition J_W-J_F=0. They have different physical net indices within the source's conditional operator/domain dictionary. These are not new computations or full quantum-complete models. They are already available counterexamples to the proposition that the presently supplied coefficient, action and local anomaly filter uniquely determine the charged boundary polarization.

The new selective-boundary checkpoint changes these choices explicitly and improves its light spectrum. Its admission does not retroactively derive its boundary from the record operations.

## 8. Input-retirement ledger and success condition

| Datum | What this gate establishes | Retired as a physical input? |
|---|---|---|
| Projective matrix scale / SL2 sign used to build V4 | Cancels in M X M^dagger/|det M| | A representation-lift redundancy, not Lorentz/spin physics |
| Twelve coordinates of the extension cocycle | End-trivial nonzero H1 ray is unique; different representatives are coboundaries | Algebraic representative not independent after the explicit hypotheses |
| Nonzero versus split extension | Both satisfy bulk representation laws; different invariant subspaces remain | No |
| Marked signed carrier m135, parity nu and the chosen Hermitian rank-four construction | Fixed source inputs; not selected by the weave | No |
| Positive harmonic/kinetic metric | Requires additional geometric/end specification | No |
| Charged boundary polarization and end response | Not fixed by peripheral monodromy or local anomaly | No |
| Physical gauge/Lorentz field dictionary and E8 parent | Reused only as supplied target | No |
| Modular cusp integer n=1 | Not the structure flux or this peripheral extension class | No |

A successful next step must supply an explicit map from retained record data to a kinetic complex AND its physical domain, with the full real structure and Green form. It must say which remaining choice is fixed without reading a desired spectrum as input. The immediate candidate duty is to derive a boundary response that admits the nonzero interior extension and fixes a charged polarization from the same action/earlier rule. Merely assigning the favourable planes, or demanding nonzero flux after inspecting the family count, does not meet that condition.

The record-to-geometric-holonomy stage must remain visible: the weaker coefficient-only quotient demonstrably lacks information needed by this model. This does not authorize a new carrier census or impose full F2 on every other route.

## 9. Verification and custody

`verify_bridge.py` passed 57/57 exact checks on its first formal run. `verify_reference.py` passed 17/17 on its first formal run. The latter uses a different lift construction, rational restriction instead of ranks directly in Q(sqrt(2)), formal affine relation derivatives, and Fraction-pair arithmetic for the word witness. It shares an author and is not independent specialist acceptance.

The formal main script was written after exploratory calculations. Its hash record is explicitly NOT a blind preregistration. The reference was written after the main result and is similarly labelled. No branch commit or external timestamp is claimed. Two exploratory scripts and their generated witnesses are preserved. One exploratory display used structural SymPy equality and printed an unsimplified Fc comparison as false; direct expansion gives zero, and the full representation relators already agreed. The final verification always tests expanded algebraic residuals. No conclusion was drawn from that false display. First formal verification scripts were not repaired after execution.

The coefficient input is byte-verified against its pinned Git blob. The complete matrices, second cocycle, peripheral splitting vector, nested word and full-parent character are included. No archived research was edited; no scientific repository file was imported at runtime or changed remotely. This packet does not rerun the silver physical census, global harmonic-metric proof, supersymmetry producer or quantum theory.

Run:

    python verify_bridge.py
    python verify_reference.py

Expected exact checks: 57 and 17. Dependencies: Python 3 and SymPy 1.14. No network is required to reproduce this packet once downloaded.

## References and retained scope

Pinned repository sources are listed with exact paths and blob identifiers in `SOURCES.json`. Primary mathematical context:

- The Hermitian-matrix SL2/Lorentz correspondence, explicitly developed in 'A Direct Road to Majorana Fields', Symmetry 2 (2010), 1776, equations 11–18. This is not used to identify internal Lorentz-valued data with physical spacetime.
- The Stacks Project, Extensions, tag 010K and Section 12.6. The concrete cocycle and splitting arguments are given here rather than assumed from terminology.
- Wu–Zhang, arXiv:2109.01776, the compact-boundary harmonic-metric result as applied in the repository's October 4 proof. That analytic application is inherited, not re-certified by the finite calculations above.

**Bottom line:** this gate finds a real information mismatch and a precise conditional algebraic reconstruction. It does not yet join the record principle to a selected physical operator or end law. Its next task is narrower because the missing information and the surviving choices are now explicitly separated.
