"""Separate-method exact control: Kronecker lift, rational restriction,
formal affine relation derivatives and Fraction-based Gaussian arithmetic.
Does not import verify_bridge or any repository producer.
"""
from pathlib import Path
from fractions import Fraction as F
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix

P=Path(__file__).resolve().parent
D=json.loads((P/'candidate.json').read_text())
r=s.sqrt(2)
flags={}
def ok(name,v):
    flags[name]=bool(v)
    if not flags[name]: raise AssertionError(name)
def clean(a):return a.applyfunc(s.expand)
def is0(a):return all(s.expand(v)==0 for v in a)
# Row-vectorization rather than applying each Hermitian basis by hand.
T=s.Matrix([[1,0,0,0],[0,0,1,s.I],[0,0,1,-s.I],[0,1,0,0]])
V={}
for g,rows in D['holonomy'].items():
    a=s.Matrix([[s.Rational(x)+s.I*s.Rational(y) for x,y in row] for row in rows])
    den=s.sqrt(s.expand(a.det()*s.conjugate(a.det())))
    V[g]=clean(D['nu'][g]*T.inv()*s.kronecker_product(a,a.conjugate())*T/den)
coords=s.symbols('c0:12')
G={g:V[g].row_join(s.Matrix(coords[4*j:4*j+4])).col_join(s.zeros(1,4).row_join(s.ones(1,1))) for j,g in enumerate('abt')}
for g in 'abt':
    vi=clean(V[g].inv());j='abt'.index(g)
    G[g.upper()]=vi.row_join(clean(-vi*s.Matrix(coords[4*j:4*j+4]))).col_join(s.zeros(1,4).row_join(s.ones(1,1)))
def prod(word):
    a=s.eye(5)
    for letter in word:a=clean(a*G[letter])
    return a
rel=[prod(w) for w in D['relators']]
end=[prod(w) for w in D['cusp_words']]
F1=s.Matrix.vstack(*(a[:4,4].jacobian(coords) for a in rel))
R=s.Matrix.vstack(*(a[:4,4].jacobian(coords) for a in end))
B=s.Matrix.vstack(*(V[g]-s.eye(4) for g in 'abt'))
Bend=s.Matrix.vstack(*(a[:4,:4]-s.eye(4) for a in end))
Aug=F1.row_join(s.zeros(8,4)).col_join(R.row_join(-Bend))
def restrict(a):
    q=s.zeros(2*a.rows,2*a.cols)
    for i in range(a.rows):
        for j in range(a.cols):
            z=s.expand(a[i,j]);b=z.coeff(r);aa=s.expand(z-b*r)
            if not aa.is_Rational or not b.is_Rational:raise ValueError('wrong arithmetic field')
            q[2*i:2*i+2,2*j:2*j+2]=s.Matrix([[aa,2*b],[b,aa]])
    return q
def rr(a):return DomainMatrix.from_Matrix(restrict(a)).convert_to(s.QQ).rank()
c=s.Matrix([s.Rational(x)+r*s.Rational(y) for x,y in D['cocycle_Qsqrt2_pairs']])
ok('all_affine_relators_have_fixed_diagonal',all(is0(a[:4,:4]-s.eye(4)) for a in rel))
ok('cocycle_linear_constraints',is0(F1*c))
ok('rational_rank_d0',rr(B)==8)
ok('rational_rank_d1',rr(F1)==12)
ok('rational_rank_end',rr(Bend)==6)
ok('rational_rank_combined',rr(Aug)==20)
ok('rational_rank_c_not_coboundary',rr(B.row_join(c))==10)
ok('rational_end_trivial',rr(Bend.row_join(clean(R*c)))==6)
ok('h1_two_and_interior_one',(24-rr(B)-rr(F1))//2==2 and (24-rr(B)-rr(Aug)+rr(Bend))//2==1)
x=s.symbols('x')
ok('kronecker_characteristic_polynomial',s.expand(V['a'].charpoly(x).as_expr()-(x*x+1)*(x*x-2*r*x+1))==0)
# Independent arbitrary-exact arithmetic for the word, using pairs of Fractions.
def plus(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def times(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def recip(a):
    n=a[0]**2+a[1]**2
    return (a[0]/n,-a[1]/n)
z=(F(0),F(0));one=(F(1),F(0))
def mm(a,b):return [[plus(times(a[i][0],b[0][j]),times(a[i][1],b[1][j])) for j in range(2)] for i in range(2)]
def mi(a):
    det=plus(times(a[0][0],a[1][1]),neg(times(a[0][1],a[1][0])))
    return [[times(v,recip(det)) for v in row] for row in [[a[1][1],neg(a[0][1])],[neg(a[1][0]),a[0][0]]]]
A={g:[[(F(x),F(y)) for x,y in row] for row in entries] for g,entries in D['holonomy'].items()}
A.update({g.upper():mi(a) for g,a in list(A.items())})
def red(w):
    previous=None
    while w!=previous:
        previous=w
        for g in 'abAB':w=w.replace(g+g.swapcase(),'')
    return w
def inverse_word(w):return w[::-1].swapcase()
def cm(a,b):return red(a+b+inverse_word(a)+inverse_word(b))
w1=cm('a','b');w2=cm(w1,red('a'+w1+'A'));w3=cm(w2,red('a'+w2+'A'))
mat=[[one,z],[z,one]]
for letter in w3:mat=mm(mat,A[letter])
tr=plus(mat[0][0],mat[1][1])
det=plus(times(mat[0][0],mat[1][1]),neg(times(mat[0][1],mat[1][0])))
ok('separate_reduction_word_length',len(w3)==54)
ok('fraction_word_det',det==one)
ok('fraction_word_trace',tr==(F(-50331646),F(2097152)))
char4=tr[0]**2+tr[1]**2
ok('fraction_four_trace',char4==F(2537672635580420))
char6=2*(tr[0]**2-tr[1]**2)-2
parent=(char4+1)**2-1+24+20*(char4+1)+10*(char6+char4)
ok('fraction_full_parent_trace',parent==F(6439782405373806910005477114104))
ok('parent_identity_not_falsely_detected',(4+1)**2-1+24+20*(4+1)+10*(6+4)==248)
# Distinguish fixed-metric equivalence from algebraic conjugacy.
norm=s.expand((c.T*c)[0]);ok('fixed_metric_norm_control',s.expand(3*norm-(798+108*r))==0)
res={'scope':'same-author separate methods, no physical census/PDE theorem','checks':flags,'passed':sum(flags.values()),'failed':[k for k,v in flags.items() if not v]}
(P/'REFERENCE_RESULTS.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
