# Record-to-physics joining gate 1

Read TECHNICAL_REPORT.md first. This is not a new physical model or a completed foundation-to-physics derivation.

## Results

- A 54-letter word killed by the quotient preserving all quaternion H1 is detected exactly by the actual silver coefficient and its supplied E8 adjoint character.
- The actual rank-four coefficient has H1 dimension two and interior H1 dimension one. The already-known nonzero end-trivial extension construction is verified at this input.
- Algebraic matrix/cocycle presentation choices can be removed conditionally; physical normalization, carrier, nonzero extension, operator and boundary selection are not removed.

## Reproduce

Python 3 with SymPy 1.14:

    python verify_bridge.py
    python verify_reference.py

57 and 17 exact checks should pass. Scripts do not use network or import project producers. Both are same-author methods. Their local pre-run hash records were created after exploration and are NOT blind preregistrations.

MATRICES.json includes the full cochain matrices, original and opposing extension classes, and the common frame that makes both peripheral extension entries vanish. RESULTS.json and REFERENCE_RESULTS.json record the calculated outputs. SOURCES.json identifies the pinned original input and the predecessors credited. No field count or PDE proof is implied by the number of finite checks.
