"""Exact coefficient/end-transport gate; no scientific producer imports.

This deliberately tests one pinned coefficient on m135, not all carriers,
a selected physical action, a PDE, or a four-dimensional particle census.
"""
from pathlib import Path
from itertools import combinations
import hashlib
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix

ROOT = Path(__file__).resolve().parent
SQ = s.sqrt(2)
K = s.QQ.algebraic_field(SQ)
DATA = json.loads((ROOT / 'candidate.json').read_text())
GEN = DATA['generators']
checks = {}

def zero(x):
    if isinstance(x, s.MatrixBase):
        return all(s.expand(v) == 0 for v in x)
    return s.simplify(x) == 0

def require(name, value):
    checks[name] = bool(value)
    if not checks[name]:
        raise AssertionError(name)

def simp(a):
    return a.applyfunc(s.simplify)

def rank(a):
    return DomainMatrix.from_Matrix(a).convert_to(K).rank()

def lift4(a):
    hs = [s.diag(1,0),s.diag(0,1),s.Matrix([[0,1],[1,0]]),s.Matrix([[0,s.I],[-s.I,0]])]
    den = s.sqrt(s.expand(a.det()*s.conjugate(a.det())))
    columns = []
    for h in hs:
        b = simp(a*h*a.conjugate().T/den)
        columns.append(s.Matrix([b[0,0],b[1,1],(b[0,1]+b[1,0])/2,(b[0,1]-b[1,0])/(2*s.I)]))
    return simp(s.Matrix.hstack(*columns))

def with_inverses(rep):
    return {**rep, **{g.upper():simp(a.inv()) for g,a in rep.items()}}

def ev(rep, word):
    dic=with_inverses(rep)
    out=s.eye(next(iter(rep.values())).rows)
    for g in word:
        out=(out*dic[g]).applyfunc(s.expand)
    return out

def fox(rep,word,generators=GEN):
    dic=with_inverses(rep)
    n=next(iter(rep.values())).rows
    p=s.eye(n)
    out={g:s.zeros(n) for g in generators}
    for g in word:
        if g.islower():
            out[g] += p
            p=(p*dic[g]).applyfunc(s.expand)
        else:
            p=(p*dic[g]).applyfunc(s.expand)
            out[g.lower()] -= p
    return s.Matrix.hstack(*(out[g] for g in generators)).applyfunc(s.expand)

def reduce_word(word):
    out=[]
    for a in word:
        if out and out[-1] == a.swapcase():
            out.pop()
        else:
            out.append(a)
    return ''.join(out)

def inv(word): return word[::-1].swapcase()
def comm(a,b): return reduce_word(a+b+inv(a)+inv(b))
def conjugate(a,b): return reduce_word(a+b+inv(a))

def extension(rep,c):
    n=next(iter(rep.values())).rows
    return {g:rep[g].row_join(c[n*j:n*j+n,:]).col_join(s.zeros(1,n).row_join(s.ones(1,1))) for j,g in enumerate(GEN)}

def enc(mat):return [[str(s.expand(v)) for v in row] for row in mat.tolist()]

raw=(ROOT/'candidate.json').read_bytes()
blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
require('input_matches_pinned_git_blob',blob=='e1e4b140bc27df46d9bc41bfdfebf8464b17fa2d')
M={g:s.Matrix([[s.Rational(a)+s.I*s.Rational(b) for a,b in row] for row in entries]) for g,entries in DATA['holonomy'].items()}
V={g:DATA['nu'][g]*lift4(a) for g,a in M.items()}
eta=s.Matrix([[0,s.Rational(1,2),0,0],[s.Rational(1,2),0,0,0],[0,0,-1,0],[0,0,0,-1]])
for g in GEN:
    require('det_V_'+g,zero(V[g].det()-1))
    require('indefinite_form_'+g,zero(V[g].T*eta*V[g]-eta))
    require('projective_scalar_independence_'+g,zero(lift4((2+3*s.I)*M[g])-lift4(M[g])))
require('Lorentz_map_composes',zero(lift4(M['a']*M['b'])-lift4(M['a'])*lift4(M['b'])))
for j,rel in enumerate(DATA['relators']):
    require('coefficient_relator_'+str(j),zero(ev(V,rel)-s.eye(4)))

x=s.symbols('x')
expected=(x*x+1)*(x*x-2*SQ*x+1)
require('exact_nonunitary_holonomy_polynomial',zero(V['a'].charpoly(x).as_expr()-expected))
# This also certifies that the determinant-normalized map needs no SL2 spin sign.
require('spin_sign_cancels',zero(lift4(-M['a'])-lift4(M['a'])))

# Reuse precisely the words in the genesis source, not a different quotient.
word_c=comm('a','b')
word_r=comm(word_c,conjugate('a',word_c))
word_t=comm(word_r,conjugate('a',word_r))
require('third_derived_word_is_nonempty',len(word_t)==54)
AQ=s.diag(s.I,-s.I);BQ=s.Matrix([[0,1],[-1,0]])
for i,(a,b) in enumerate(((1,1),(1,-1),(-1,1),(-1,-1))):
    q={'a':a*AQ,'b':b*BQ}
    require('Q8_word_identity_'+str(i),zero(ev(q,word_t)-s.eye(2)))
    require('all_Q8_cocycles_blind_'+str(i),zero(fox(q,word_t,'ab')))
    require('second_derived_opposing_cocycle_'+str(i),fox(q,word_r,'ab').rank()==2)
mt=ev(M,word_t)
tr2=s.expand(s.trace(mt))
require('word_SL2_determinant',zero(mt.det()-1))
require('geometric_word_trace',zero(tr2-(-50331646+2097152*s.I)))
vt=ev(V,word_t)
tr4=s.expand(s.trace(vt))
require('direct_four_word_matches_two_spinors',zero(tr4-tr2*s.conjugate(tr2)))
require('physical_word_is_detected',tr4==s.Integer(2537672635580420) and tr4!=4)

# Actual extension problem: C0 -> C1 -> C2, with one cusp torus.
B=s.Matrix.vstack(*(V[g]-s.eye(4) for g in GEN))
F=s.Matrix.vstack(*(fox(V,w) for w in DATA['relators']))
R=s.Matrix.vstack(*(fox(V,w) for w in DATA['cusp_words']))
DB=s.Matrix.vstack(*(ev(V,w)-s.eye(4) for w in DATA['cusp_words']))
Aug=F.row_join(s.zeros(F.rows,4)).col_join(R.row_join(-DB))
c=s.Matrix([s.Rational(a)+SQ*s.Rational(b) for a,b in DATA['cocycle_Qsqrt2_pairs']])
require('cochain_d_squared',zero(F*B))
require('boundary_restriction_cochain',zero(R*B-DB))
require('cocycle_is_closed',zero(F*c))
require('cocycle_is_not_exact',rank(B.row_join(c))==5)
require('absolute_rank_certificate',(rank(B),rank(F))==(4,6))
require('end_rank_certificate',(rank(DB),rank(Aug))==(3,10))
h1=12-rank(F)-rank(B)
hint=12-rank(B)-rank(Aug)+rank(DB)
require('absolute_two_interior_one',(h1,hint)==(2,1))
require('selected_class_is_end_trivial',rank(DB.row_join(simp(R*c)))==rank(DB))

# Construct a second extension class: cocycle, not exact, and not end-trivial.
Z=DomainMatrix.from_Matrix(F).convert_to(K).nullspace().to_Matrix().T
z=next(Z[:,j] for j in range(Z.cols) if rank(B.row_join(c).row_join(Z[:,j]))==6)
z=simp(z)
require('opposing_class_closed',zero(F*z))
require('opposing_class_independent',rank(B.row_join(c).row_join(z))==6)
require('opposing_class_changes_end',rank(DB.row_join(simp(R*z)))==4)
sol,pars=DB.gauss_jordan_solve(simp(R*c))
sol=simp(sol.subs({v:0 for v in pars}))
cend=simp(c-B*sol)
require('one_frame_cancels_both_end_cocycles',zero(R*cend))
require('end_gauge_does_not_erase_bulk_class',rank(B.row_join(cend))==5)
W=extension(V,c)
Wend=extension(V,cend)
Wsplit=extension(V,s.zeros(12,1))
U=s.eye(5);U[:4,4]=sol
for j,pword in enumerate(DATA['cusp_words']):
    split_end=s.diag(ev(V,pword),s.ones(1,1))
    require('exact_split_end_frame_'+str(j),zero(U*ev(W,pword)*U.inv()-split_end))
for j,rel in enumerate(DATA['relators']):
    require('full_five_relator_'+str(j),zero(ev(W,rel)-s.eye(5)))
require('split_has_one_invariant',5-rank(s.Matrix.vstack(*(Wsplit[g]-s.eye(5) for g in GEN)))==1)
require('nonsplit_has_no_invariant',5-rank(s.Matrix.vstack(*(W[g]-s.eye(5) for g in GEN)))==0)
require('five_characteristic_polynomial',zero(W['a'].charpoly(x).as_expr()-(x-1)*expected))
scale=s.symbols('scale',nonzero=True)
S=s.diag(scale,scale,scale,scale,1)
Ws=extension(V,scale*c)
require('nonzero_amplitude_is_algebraic_conjugacy',all(zero(S*W[g]*S.inv()-Ws[g]) for g in GEN))
# A fixed positive metric can distinguish amplitude even though GL-conjugate.
W2=extension(V,2*c)
HSdiff=s.simplify(sum(s.trace(W2[g].conjugate().T*W2[g])-s.trace(W[g].conjugate().T*W[g]) for g in GEN))
require('fixed_metric_not_unitary_equivalence',HSdiff>0 and zero(HSdiff-3*(c.conjugate().T*c)[0]))

# Lift the detected word to the full E8 trace using the source's branching.
wt=ev(W,word_t); wti=simp(wt.inv())
ii=list(combinations(range(5),2))
def ext_trace(a):return s.expand(sum(a[i,i]*a[j,j]-a[i,j]*a[j,i] for i,j in ii))
e8=s.expand(24+s.trace(wt)*s.trace(wti)-1+10*(s.trace(wt)+s.trace(wti))+5*(ext_trace(wt)+ext_trace(wti)))
ss=s.expand(tr2**2+s.conjugate(tr2)**2-2)
e8ref=s.expand(tr4**2+32*tr4+44+10*ss)
require('E8_trace_two_formulas_agree',zero(e8-e8ref))
require('full_parent_detects_word',e8!=248)
require('branching_identity_control',24+(5*5-1)+10*(5+5)+5*(10+10)==248)

out={'scope':'One pinned marked m135 coefficient and its extension/end-transport problem; not a physical operator/domain derivation',
 'checks':checks,'passed':sum(checks.values()),'failed':[k for k,v in checks.items() if not v],
 'candidate_git_blob':blob,'field':'Q(sqrt(2)) for four/five coefficients; Q(i) for projective spinor word',
 'rank_certificate':{'d0':rank(B),'d1':rank(F),'peripheral_d0':rank(DB),'combined_relative':rank(Aug),'absolute_h1':h1,'interior_h1':hint},
 'word':{'commutator':word_c,'second_derived':word_r,'third_derived':word_t,'length':len(word_t),'trace2':str(tr2),'trace4':str(tr4),'E8_trace':str(e8)},
 'fixed_metric_HS_difference':str(HSdiff),
 'claims_not_established':['selection of m135 or nu','need for nonzero extension','physical kinetic normalization','Lorentz or E8 parent derivation','physical boundary polarization or cusp unit','new physical particle spectrum']}
(ROOT/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
mat={'V4':{g:enc(v) for g,v in V.items()},'W5':{g:enc(v) for g,v in W.items()},'d0':enc(B),'d1':enc(F),'restriction':enc(R),'peripheral_d0':enc(DB),
     'original_cocycle':enc(c),'opposing_class':enc(z),'end_frame_vector':enc(sol),'end_trivial_representative':enc(cend),'word_matrix2':enc(mt)}
(ROOT/'MATRICES.json').write_text(json.dumps(mat,indent=2)+'\n')
print(json.dumps(out,indent=2))
