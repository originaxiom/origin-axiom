from pathlib import Path
import json, sympy as s
p=Path(__file__).parent;data=json.loads((p/'candidate.json').read_text())
A={g:s.Matrix([[s.Rational(a)+s.I*s.Rational(b) for a,b in row] for row in en]) for g,en in data['holonomy'].items()}
A.update({g.upper():m.inv().applyfunc(s.expand) for g,m in list(A.items())})
def red(w):
    stack=[]
    for c in w:
        if stack and c==stack[-1].swapcase():stack.pop()
        else:stack.append(c)
    return ''.join(stack)
def inv(w):return w[::-1].swapcase()
def com(v,w):return red(v+w+inv(v)+inv(w))
def conj(v,w):return red(v+w+inv(v))
c=com('a','b');r=com(c,conj('a',c));t=com(r,conj('a',r))
M=s.eye(2)
for ch in t:M=(M*A[ch]).applyfunc(s.expand)
tr=s.expand(s.trace(M));det=s.expand(M.det());tr4=s.expand(tr*s.conjugate(tr))/s.sqrt(det*s.conjugate(det))
print('word_lengths',len(c),len(r),len(t));print('t',t)
print('trace2',tr);print('det',det);print('trace4',s.simplify(tr4));print('tr4minus4',s.simplify(tr4-4))
out={'c':c,'r':r,'t':t,'trace2':str(tr),'det2':str(det),'trace4':str(s.simplify(tr4)), 'matrix2':[[str(x) for x in row] for row in M.tolist()]}
(p/'witness.json').write_text(json.dumps(out,indent=2)+'\n')
