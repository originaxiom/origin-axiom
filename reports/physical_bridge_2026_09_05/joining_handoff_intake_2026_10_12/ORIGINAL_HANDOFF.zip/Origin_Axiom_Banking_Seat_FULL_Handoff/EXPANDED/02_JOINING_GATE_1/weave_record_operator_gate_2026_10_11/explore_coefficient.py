from pathlib import Path
import json, sympy as s
from sympy.polys.matrices import DomainMatrix
p=Path(__file__).parent
D=json.loads((p/'candidate.json').read_text())
K=s.QQ.algebraic_field(s.sqrt(2))
clean=lambda A:A.applyfunc(s.simplify)
rank=lambda A:DomainMatrix.from_Matrix(A).convert_to(K).rank()
bas=[s.diag(1,0),s.diag(0,1),s.Matrix([[0,1],[1,0]]),s.Matrix([[0,s.I],[-s.I,0]])]
def lor(A):
    scale=s.sqrt(s.expand(A.det()*s.conjugate(A.det())))
    cols=[]
    for h in bas:
        z=clean(A*h*A.conjugate().T/scale)
        cols.append(s.Matrix([z[0,0],z[1,1],(z[0,1]+z[1,0])/2,(z[0,1]-z[1,0])/(2*s.I)]))
    return clean(s.Matrix.hstack(*cols))
M={g:s.Matrix([[s.Rational(a)+s.I*s.Rational(b) for a,b in row] for row in ent]) for g,ent in D['holonomy'].items()}
V={g:D['nu'][g]*lor(A) for g,A in M.items()}
def letters(rep):return {**rep,**{g.upper():clean(v.inv()) for g,v in rep.items()}}
def ev(rep,w):
    a=letters(rep);out=s.eye(next(iter(rep.values())).rows)
    for c in w:out=clean(out*a[c])
    return out
def fox(rep,w):
    A=letters(rep);N=next(iter(rep.values())).rows;pre=s.eye(N);blocks={g:s.zeros(N) for g in D['generators']}
    for c in w:
        if c.islower():blocks[c]+=pre;pre=clean(pre*A[c])
        else:pre=clean(pre*A[c]);blocks[c.lower()]-=pre
    return clean(s.Matrix.hstack(*(blocks[g] for g in D['generators'])))
x=s.symbols('x')
B=s.Matrix.vstack(*(V[g]-s.eye(4) for g in D['generators']))
F=s.Matrix.vstack(*(fox(V,w) for w in D['relators']))
c=s.Matrix([s.Rational(a)+s.sqrt(2)*s.Rational(b) for a,b in D['cocycle_Qsqrt2_pairs']])
print('relators', [ev(V,w)==s.eye(4) for w in D['relators']])
print('V_a = ',V['a']);print('charpolyV_a',s.factor(V['a'].charpoly(x).as_expr(),extension=s.sqrt(2)))
print('rank B,F,B|c',rank(B),rank(F),rank(B.row_join(c)))
print('Fc zero',F*c==s.zeros(8,1),'h1',12-rank(F)-rank(B))
W={g:V[g].row_join(c[4*i:4*(i+1),:]).col_join(s.zeros(1,4).row_join(s.ones(1,1))) for i,g in enumerate(D['generators'])}
print('W relators',[ev(W,w)==s.eye(5) for w in D['relators']])
print('charpolyWa',s.factor(W['a'].charpoly(x).as_expr(),extension=s.sqrt(2)))
print('V cusp mu eigen',s.factor(ev(V,D['cusp_words'][0]).charpoly(x).as_expr(),extension=s.sqrt(2)))
print('V cusp lam eigen',s.factor(ev(V,D['cusp_words'][1]).charpoly(x).as_expr(),extension=s.sqrt(2)))
R=s.Matrix.vstack(*(fox(V,w) for w in D['cusp_words']))
DB=s.Matrix.vstack(*(ev(V,w)-s.eye(4) for w in D['cusp_words']))
Aug=F.row_join(s.zeros(8,4)).col_join(R.row_join(-DB))
print('Fc simplified',clean(F*c)==s.zeros(8,1))
print('ranks R,DB,Aug',rank(R),rank(DB),rank(Aug))
print('interior H1',12-rank(B)-rank(Aug)+rank(DB))
print('selected_c_peripheral_exact',rank(DB.row_join(clean(R*c)))==rank(DB))
Z=DomainMatrix.from_Matrix(F).convert_to(K).nullspace().to_Matrix().T
print('Z basis',Z.shape)
span=B
representatives=[]
for j in range(Z.cols):
    if rank(span.row_join(Z[:,j]))>rank(span):
        representatives.append(Z[:,j]);span=span.row_join(Z[:,j])
print('representatives',representatives)
print('peripheral exact flags',[rank(DB.row_join(clean(R*z)))==rank(DB) for z in representatives])
# Witness extending the selected class to a non-interior independent class.
for z in representatives:
    if rank(B.row_join(c).row_join(z))==6:
        print('c2 =',z.T);print('c2 notinterior',rank(DB.row_join(clean(R*z)))>rank(DB))
        (p/'extra_class.json').write_text(json.dumps([str(s.simplify(v)) for v in z],indent=2)+'\n')
        break
