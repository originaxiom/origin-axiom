# Next joining gate — one generated end/response choice

Do not reopen the completed quaternion cohomology quotient, phase census, or selective-boundary admission. Keep the findings and scope in TECHNICAL_REPORT.md.

## Question

Can an earlier record-based rule determine a nonzero admissible structure response AND a charged operator boundary polarization in one already specified parent, rather than inserting either from the desired spectrum?

## Why this precise target

The same quaternion H1 data can conceal a word read by the actual geometric coefficient. The joining map must retain enough record geometry before it passes to a compressed module. Given the chosen geometric coefficient, a nonzero end-trivial extension ray is already unique, but the zero extension is not ruled out by noncommutation. Peripheral holonomy can remain unchanged while a nonsplit harmonic solution needs a nonzero real structure flux. Physical gauge projection, structure flux and modular-cusp integer are distinct quantities.

## Required delivered map

State the source data, the generated carrier/representation or every supplied remainder, the positive real structure, differential and its adjoint, the physical field embedding, the boundary trace and its Green annihilator. A determinant-line construction must name the family/base and may not replace a matter-twist line without a map. The source's complete field and dual roster must be carried along.

## Opposing cases required in the same test

The split and nonzero interior extensions, a cocycle with nontrivial peripheral restriction, and two source-admitted charged polarizations of different net index must remain explicit. A rule that accepts all of them has not selected among them. A rule that discards one because it has the wrong requested family number is not upstream evidence. A rule that changes the metric or gauge/end law must record that change.

## Success accounting

Name precisely one old input and demonstrate that it now follows from earlier independently motivated data. Mathematical coordinate choices already known to be redundant do not count as a new physical assumption removed. A necessary response equation conditional on a preselected nonsplit branch is useful but does not select the branch. A conditional result can advance the full goal without claiming all spacetime, three families, interactions, anomalies or gravity have been derived.

No candidate end action is asserted to satisfy this gate yet. No source or boundary sector is added in this packet.
