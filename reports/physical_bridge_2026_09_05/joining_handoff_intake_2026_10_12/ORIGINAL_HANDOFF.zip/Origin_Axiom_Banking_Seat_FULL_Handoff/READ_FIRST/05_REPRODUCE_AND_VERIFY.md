# SCIENTIFIC AND ARCHIVE REPRODUCTION

**Archive verification:** `python3 VERIFY_HANDOFF.py` (standard-library only) validates SHA-256 of every handoff member except its own manifest and metadata, validates original ZIP CRCs, and compares original ZIP entries against browsable extracted copies. See MANIFEST_SHA256.json.

**Research verification:** Every original run README lists its environment and scripts, with final and failed outputs stored unchanged. Most require SymPy and mpmath; several use NumPy. The original archive includes Run 1–13 scripts; no scientific code is executed when building this banking handoff. Each joining gate's README and TECHNICAL_REPORT list its reproduction commands. Do not interpret a large passing-test count as independent mathematical acceptance.

**Reference and branch pins:** The joining gate source manifests hold the exact source-ref + hash pairs. The cross-branch review was dated 2026-10-11 and branches moved during subsequent physics runs. Before adopting any statement, fetch all advertised remote branch heads and compare latest successors, especially `audit/physical-bridge-2026-09-05` and `audit/fork-2026-09-20`. Source branch heads are not immutable scientific priorities; reports and their pin references are.

**Banking:** Create a new dated arc/branch/checkpoint for additional results. Never silently replace any archived file, log or pre-seal state. Treat arithmetic exact claims, numeric observational checks, authored analytic proofs, physical-model conditional choices, and new hypotheses separately.
