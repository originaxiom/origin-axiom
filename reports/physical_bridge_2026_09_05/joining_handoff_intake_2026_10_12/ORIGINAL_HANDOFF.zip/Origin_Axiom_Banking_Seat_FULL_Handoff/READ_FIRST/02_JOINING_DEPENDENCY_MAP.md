# HIGHEST-LEVERAGE JOINING MAP AND FAILURE CONDITIONS

The programme has two individually substantive but not yet identified chains:

**Mathematical:** two integer record moves L,R (postulated with faithful geometric setting) -> punctured-torus/F2 transport -> Q8/parity cohomology V=T+Tbar -> genuine Mp2(Z) theta multiplier and modular-weight calculations.

**Physical:** supplied compact E8/SU5 action + specified marked silver coefficient + positive harmonic metric + *supplied* complementary/selected boundary -> complete physical bosonic and fermionic operators -> conditional SM gauge phase -> charged-pair lifting and/or a selective boundary, at that branch's own grade.

Joining Gate 1 supplies an exact **information-loss witness**: a nontrivial 54-letter w in F^(3) is invisible to every Q8 doublet cocycle (and its lifted cohomology action descends to F/F^(3)), but the actual m135 physical coefficient V(w) is not identity. Hence a map through only the compressed Q8 triplet cannot reconstruct that connection. Need richer record/geometric data at the input.

Gate 1 also finds H1(m135,V) dimension 2, but interior H1 dimension 1. Specified V + nonzero extension + unchanged peripheral extension transport gives ONE nonzero rank-5 extension isomorphism class; it does not select nonzero vs split, gauge/Lorentz interpretation, a positive kinetic metric or the physical domain. The source's nonsplit harmonic flag identity requires a strictly negative total normal boundary response, not a fixed cusp integer.

Gate 2 demands a **whole-geometry response** rather than an assigned projector: on-shell elimination yields N_Y(p), with exact q-form cusp N_q(p)=sqrt(p²+((1-q)/ell)²)-(1-q)/ell. Tangential one-form q=1 has N=p and essential spectrum [0,infty), no normalizable zero mode. Nonsplit harmonic flag current makes finite ∫|Psi|² impossible under one infinite cusp continuation, but ∫(|F|²+|mu|²) is a different physical potential and can remain zero. A fully SU5-equivariant exterior cannot produce a 3+2-selective boundary without actual symmetry-breaking fields or state.

Gate 3 constructs a nonabelian exact peripheral end candidate with b(r)=b0 e^(2r/ell), supplied by flat/moment-zero field equations. In nonzero Xi-charge sectors H=A†A is a growing-potential radial Schrödinger system with normalizable tail. The exact DtN N_sigma has Whittaker solution and N_+(p)N_-(p)=p², Z=(ell/2)e^x E1(x) finite when b0>0. Neutral Xi-charge channels remain gapless, at least a gauge commuting sector. b0 is not selected by the bare potential; its would-be modulus is nonnormalizable. The scalar current matching condition b0=J0/(20A0) is NOT full nonabelian core-to-end matching.

## Explicit input-retirement test

A new proof must identify (A) its earlier source data, (B) the named downstream formerly supplied input, (C) the exact implication, (D) different alternatives it excludes, (E) the complete physical action/operator metric and closed domain, and (F) the observable or spectral effect. In particular, no credit for 'selects three' unless the end law is derived before looking at the family count.

## Proposed next decisive calculations

- Solve the **full matrix-valued nonlinear core/end matching** for the existing m135 nonsplit coefficient and positive harmonic metric; retain all tangential/normal components and both charged/neutral sectors. Classify when the end with actual peripheral matrices is smooth and finite according to the *actual action and kinetic norm*.
- Derive Calderon/DtN end response for the complete physical R/Weyl/adjoint bundle (including neutral continuum), not only scalar charged controls. Identify whether it matches any admitted compact-core cyclic boundary, and which parameters remain free.
- Test the full superfield variation, gauge, reality, boundary current, anomaly/inflow and finite normalization on the resulting joint domain. A change to a new selective gauge boundary must be explicitly counted as new physics, not disguised as equivalence.
- Only THEN compute 3-family capacity, Higgs scalar potential, charged Yukawa/normalized global overlaps and predict observables. Latest physical-branch charged cubic work should be inspected before repeating any charged tensor computation.

## Unresolved foundational and physical inputs

PF1–PF3/GM substrate assumptions; legal signed moves/carrier; geometric marked thread and coefficient; source/supplied E8 action and embedding; positive metric and compact cut; split-vs-nonsplit extension; choice of flux sector and asymptotic state; actual spacetime/Lorentz/gauge matter dictionary Lambda; physical boundary polarization/grade; 3-family realization; symmetry breaking and unwanted light modes; anomaly/global quantum consistency; dimensionful scale and measured parameters; gravitational dynamics. These are not known derived by the joining gates.
