#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())['files']
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
for item in manifest:
 p=ROOT/item['path']
 assert p.is_file() and p.stat().st_size==item['size'] and sha(p)==item['sha256'],f'FAIL {item["path"]}'
arch=json.loads((ROOT/'READ_FIRST/ORIGINAL_PACKAGE_CUSTODY.json').read_text())
index={"Weave_All_13_Runs_Artifact_Archive.zip":"01_ARCHIVE_RUNS_01_TO_13", "Weave_Record_to_Physics_Joining_Gate_1.zip":"02_JOINING_GATE_1", "Weave_Record_to_Physics_Joining_Gate_2.zip":"03_JOINING_GATE_2", "Weave_Record_to_Physics_Joining_Gate_3.zip":"04_JOINING_GATE_3", "Origin_Axiom_Cross_Branch_Review_2026-10-11.zip":"05_CROSS_BRANCH_REVIEW"}
total=0
for a in arch:
 p=ROOT/'ORIGINAL_PACKAGES'/a['archive'];assert sha(p)==a['sha256']
 with ZipFile(p) as z:
  assert z.testzip() is None
  for m in z.infolist():
   if m.is_dir():continue
   assert (ROOT/'EXPANDED'/index[a['archive']]/m.filename).read_bytes()==z.read(m)
   total+=1
print('VERIFIED',len(manifest),'files by SHA256 and',total,'original ZIP entries byte-for-byte; source PDF duplicate verified at creation.')
